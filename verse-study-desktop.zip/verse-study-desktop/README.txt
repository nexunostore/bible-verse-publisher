VERSE STUDY (desktop)
=====================
Type a verse, get the exact KJV text plus meaning, context, key words and cross-references.

SET UP (once)
1. Install Python 3 (python.org) if you don't have it. No other packages are needed.
2. Get ONE API key: Anthropic (console.anthropic.com) or OpenAI/ChatGPT API (platform.openai.com).
   Note: a ChatGPT subscription is separate from an OpenAI API key; you need an API key.
3. Copy .env.example to a new file named .env, remove the # in front of the line for your provider,
   and paste your key after the = sign. (The leading dot matters. Never share this file.)
   If you set both keys, add VERSE_STUDY_PROVIDER=anthropic or openai to choose.

RUN
- Windows: double-click Start-Windows.bat
- Mac/Linux: run Start-Mac-Linux.command (on a Mac you may need: chmod +x Start-Mac-Linux.command)
Your browser opens at http://localhost:8765. Close the black window to stop it.

NOTES
- Your key stays on your computer. The app only listens on localhost.
- Each study makes one API call, which costs a small amount on your Anthropic account.
- Default models: claude-sonnet-5-5 (Anthropic), gpt-4o (OpenAI). If a model name is rejected, set
  VERSE_STUDY_MODEL in .env to one your account can use.
- The AI notes can contain mistakes. Check key words in a lexicon before you publish.
