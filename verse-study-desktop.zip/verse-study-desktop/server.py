#!/usr/bin/env python3
"""Verse Study: local app. Serves index.html and relays study requests to the Anthropic API.
Your API key stays on your computer (ANTHROPIC_API_KEY env var or a .env file next to this script)."""
import json, os, sys, threading, urllib.request, urllib.error, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).parent
PORT = int(os.environ.get("PORT", "8765"))

DEFAULTS = {"anthropic": "claude-sonnet-5-5", "openai": "gpt-4o"}

def load_config():
    """Reads settings from the environment and an optional .env file next to this script.
    Uses ANTHROPIC_API_KEY or OPENAI_API_KEY. If both are set, VERSE_STUDY_PROVIDER picks one (default: anthropic)."""
    cfg = {k: v for k, v in os.environ.items() if k.startswith(("ANTHROPIC_", "OPENAI_", "VERSE_STUDY_"))}
    env = next((f for f in (HERE / ".env", HERE / ".env.txt") if f.exists()), None)  # .env.txt: Notepad adds .txt
    if env:
        for line in env.read_text(encoding="utf-8-sig").splitlines():  # utf-8-sig: ignores the BOM Notepad adds
            line = line.strip()
            if line.startswith("export "):
                line = line[7:].strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if v and not v.startswith("paste-your"):
                    cfg.setdefault(k, v)
    keys = {"anthropic": cfg.get("ANTHROPIC_API_KEY", ""), "openai": cfg.get("OPENAI_API_KEY", "")}
    want = cfg.get("VERSE_STUDY_PROVIDER", "").lower()
    if want in keys and keys[want]:
        prov = want
    else:
        prov = next((p for p in ("anthropic", "openai") if keys[p]), None)
    if not prov:
        return None
    model = cfg.get("VERSE_STUDY_MODEL") or cfg.get(prov.upper() + "_MODEL") or DEFAULTS[prov]
    base = cfg.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    return {"provider": prov, "key": keys[prov], "model": model, "base": base}

def ask(cfg, prompt):
    if cfg["provider"] == "anthropic":
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps({"model": cfg["model"], "max_tokens": 3000,
                             "messages": [{"role": "user", "content": prompt}]}).encode(),
            headers={"x-api-key": cfg["key"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            j = json.load(r)
        return "".join(b.get("text", "") for b in j.get("content", []) if b.get("type") == "text")
    req = urllib.request.Request(
        cfg["base"] + "/chat/completions",
        data=json.dumps({"model": cfg["model"], "max_completion_tokens": 3000,
                         "response_format": {"type": "json_object"},
                         "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"Authorization": "Bearer " + cfg["key"], "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        j = json.load(r)
    return j["choices"][0]["message"]["content"] or ""

class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _host_ok(self):
        return self.headers.get("Host", "").split(":")[0] in ("localhost", "127.0.0.1")

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        if self.path in ("/", "/index.html"):
            return self._send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
        self._send(404, {"error": "not found"})

    def do_POST(self):
        # Local-only guards: right host, custom header (blocks other websites from using your key)
        if self.path != "/api/study" or not self._host_ok() or self.headers.get("X-Verse-Study") != "1":
            return self._send(403, {"error": "forbidden"})
        cfg = load_config()
        if not cfg:
            return self._send(400, {"code": "no_key", "error": "No API key found."})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            prompt = json.loads(self.rfile.read(min(n, 20000)))["prompt"]
            if not isinstance(prompt, str) or len(prompt) > 12000:
                raise ValueError
        except Exception:
            return self._send(400, {"code": "bad_request", "error": "Bad request."})
        try:
            self._send(200, {"text": ask(cfg, prompt)})
        except urllib.error.HTTPError as e:
            code = {401: "bad_key", 403: "bad_key", 404: "bad_model", 429: "rate_limited"}.get(e.code, "api_error")
            if e.code == 400 and cfg["provider"] == "openai":
                code = "bad_model"
            self._send(502 if code == "api_error" else e.code, {"code": code, "error": f"API error {e.code}"})
        except Exception:
            self._send(502, {"code": "network", "error": "Could not reach the API."})

    def log_message(self, *a):
        pass

if __name__ == "__main__":
    _f = next((f for f in (HERE / ".env", HERE / ".env.txt") if f.exists()), None)
    print("Looking for settings in:", HERE)
    print("Settings file found:", _f.name if _f else "NONE (no .env file in that folder)")
    _c = load_config()
    if not _c:
        print("\nNo API key found. Create a file named .env next to server.py containing ONE of:\n  ANTHROPIC_API_KEY=your-key\n  OPENAI_API_KEY=your-key\n(Verses will still load, but study notes need a key.)\n")
    else:
        print(f"Using {_c['provider']} with model {_c['model']}")
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    except OSError:
        sys.exit(f"Port {PORT} is busy. Close the other copy, or set PORT=8766 and try again.")
    url = f"http://localhost:{PORT}/"
    print(f"Verse Study running at {url}  (press Ctrl+C to stop)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
