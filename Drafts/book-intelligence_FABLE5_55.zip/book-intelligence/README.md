# Book Intelligence — Local/Offline EPUB Pipeline

A fully local, offline-capable pipeline: drop EPUBs in a folder, get them
parsed, chunked, embedded, and summarized, then ask cross-book questions
that get answered with citations back to specific books and chapters.

Everything runs on your machine. No data leaves it. The only network calls
ever made are one-time model downloads (Ollama models, and the reranker
from Hugging Face) — after that, disconnect and it still works.

## Architecture

```
Incoming Folder (EPUBs)
        │
        ▼
  SHA256 hash ──► duplicate? ──► reject
        │ no
        ▼
   Parse EPUB (ebooklib)
   - metadata (title/author/ISBN/etc.)
   - cover image
   - TOC-ordered chapters with clean text
        │
        ▼
  Chapter-aware chunking (~350 words, 50 overlap)
        │
        ▼
  Embed chunks (Ollama: nomic-embed-text)
        │
        ├──► Qdrant (vectors + payload)
        └──► Postgres (full text + metadata)
        │
        ▼
  Summarize book (Ollama: qwen3:14b)
        │
        ▼
  Extract major concepts/themes (Ollama: qwen3:14b)
  → deduped + linked across your whole library
        │
        ▼
     Mark complete
```

**Book intelligence captured per book:** title, author, ISBN, language,
publisher, cover, a written summary, and a set of major ideas/themes/
concepts (each with a short note on how *this* book treats it and a 1-5
importance rating). Concepts are canonicalized across your library —
"habit formation" mentioned in 5 books becomes one node, linked 5 times —
which is what makes the knowledge map below possible.

**Schema also includes tables that are in place but not yet driving
behavior**, added now while the database is still empty to avoid a
messier retrofit later: `authors`/`book_authors` (structured, multi-author
support — populated automatically, but nothing queries it yet beyond
what `books.author` already gives you), `chapters` (populated per book,
ready for future per-chapter summaries), `concept_relations` (typed
concept-to-concept links like "contradicts"/"builds on" — schema only,
no extraction step yet), `user_book_meta` (reading status/rating/notes —
schema only), `query_history`/`query_citations` (every question you ask
and what it cited — logged automatically by `query.py`), and `series`
(schema only). None of these need to be "used" for the system to work;
they're just there so adding the feature later doesn't require a data
migration.

Query side:

```
Your question
     │
     ▼
Embed question ──► Qdrant search (top 40, wide net)
     │
     ▼
Rerank (bge-reranker-v2-m3) ──► top 12, precision pass
     │
     ▼
Group results by book
     │
     ▼
Local LLM synthesizes a comparative, cited answer
```

## 1. Start the services

```bash
docker compose up -d
```

This starts Postgres (schema auto-loaded on first boot), Qdrant, and
Ollama. `db/schema.sql` runs automatically the first time — it's the
full, consolidated schema (books, authors, chapters, chunks, concepts,
concept_relations, user_book_meta, query_history, series), so there's
no separate migration step for a fresh install.

> If you'd previously already run `docker compose up` and have a
> populated Postgres volume from an earlier version of this schema,
> Postgres won't re-run `schema.sql` on an existing volume — you'd need
> to run the new `CREATE TABLE` / `ALTER TABLE` statements by hand, or
> just `docker compose down -v` to wipe and reinitialize since there's
> no real data yet.

## 2. Pull the local models (one-time, needs internet)

```bash
docker exec book_intel_ollama ollama pull nomic-embed-text
docker exec book_intel_ollama ollama pull qwen3:8b
docker exec book_intel_ollama ollama pull qwen3:14b
```

On an 8–12GB GPU: `qwen3:8b` is your responsive query-time model,
`qwen3:14b` is worth using for the (non-interactive, batch) book
summarization step during import where quality matters more than speed.
If 14B is too slow/tight on your card, just set `LLM_MODEL_DEEP=qwen3:8b`
in `.env` and use one model for everything.

## 3. Python environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

The reranker (`BAAI/bge-reranker-v2-m3`) downloads automatically from
Hugging Face the first time `query.py` runs, then is cached locally under
`~/.cache/huggingface` — fully offline from then on.

## 4. Configure

```bash
cp .env.example .env
# edit .env if you want different folders/models
```

## 5. Import your library

Bulk-import everything already sitting in a folder:

```bash
cp /path/to/your/epubs/*.epub incoming/
cd src
python pipeline.py --once
```

Or leave it watching for new drops:

```bash
python pipeline.py --watch
```

Each file is hashed, deduped, parsed, chunked, embedded, stored, and
summarized. Progress and any failures are tracked in the `import_jobs`
table in Postgres — check there if something didn't import cleanly
(most common cause: a DRM-protected EPUB with no extractable text).

## 5b. Importing a structured JSON Bible (exact chapter/verse boundaries)

If you have a Bible in the `bible-api`-style JSON format — one file per
chapter, e.g. `books/psalms/chapters/53.json` containing verse objects —
this imports it with **exact** chapter boundaries, no heuristics needed
(unlike an EPUB Bible, where chapter breaks have to be guessed from
formatting).

Each book of the Bible (Genesis, Psalms, Matthew, ...) is imported as its
own separate book in your library — so Psalms gets its own accurate
summary and themes instead of being diluted into "the whole Bible's major
themes."

```bash
cd src
python import_bible_json.py "D:\path\to\bible-api\versions\asv\books" --version "ASV"
```

Point it at the `books` folder (the one containing a subfolder per Bible
book). It recognizes the standard 66-book slugs (`1-chronicles`,
`song-of-solomon`, etc.); anything it doesn't recognize gets a best-effort
title instead of failing. Handles both a bare verse array and a wrapped
`{"verses": [...]}` object per chapter file, since that shape varies
between JSON Bible dumps — tested against both before shipping, but
worth spot-checking your first few imported books/chapters.

## 6. Check how a book's chapters got captured

```bash
cd src
python list_chapters.py "holy bible"
```

Shows the actual stored chapter titles/word counts for a book. Two things
worth knowing about how chapters get extracted:

- **Multiple books/sections packed into one file get split correctly.**
  Some EPUBs (Bibles especially) bundle several short sections into a
  single physical XHTML file, referenced by different anchors in the
  table of contents. The parser detects this and splits them apart,
  rather than losing all but one title.
- **Bible-style chapters get subdivided automatically.** If a book's TOC
  only has one entry for an entire book (e.g. "JOHN" covering all 21
  chapters, with no per-chapter TOC entries), the parser looks for the
  verse-numbering pattern (`1:1`, `1:2`... `2:1`, `2:2`...) inside the
  text and splits on chapter boundaries itself — turning "JOHN" into
  "JOHN 1", "JOHN 2", ... "JOHN 21". This only fires when the text
  strongly matches that pattern, so it won't misfire on regular prose.

If a book was imported before this fix, you'll need to remove and
re-import it to get the corrected chapter breakdown:
```bash
python remove_book.py "holy bible"
python pipeline.py --once
```

## 7. Look up a single book's stored intelligence

```bash
cd src
python book_report.py "atomic habits"
```

Prints title, author, ISBN, the stored summary, and every extracted
concept/theme with its importance rating — a quick way to sanity-check
what the pipeline captured for a given book.

## 8. Generate the knowledge map

```bash
cd src
python knowledge_map.py
# or, to declutter and only show ideas shared across multiple books:
python knowledge_map.py --min-books 2
# original physics-simulated graph instead of the interactive dropdown:
python knowledge_map.py --style network
```

Writes an interactive HTML file (`library/knowledge_map.html` by default)
— open it in any browser. Nodes are concepts (sized by how many books
touch on them), edges connect concepts that co-occur in the same book(s).
A dropdown at the top lets you focus on one concept (e.g. "Grace") and
see just what it co-occurs with, instead of the whole concept graph at
once — same interactive style as the book-to-book map below. No server,
no network — a self-contained local file.

**Note:** since each book's concepts are extracted independently, two
books rarely produce the *exact same* concept wording even when covering
the same idea (e.g. "Divinity of Christ" vs. "Christ's Divine Nature") —
so this graph will under-connect related books. For "how do these books
relate to each other," use `book_map.py` below instead.

## 8b. Rank concepts by how many books discuss them

```bash
cd src
python top_concepts.py                    # top 20 most-discussed concepts
python top_concepts.py --search parable    # find parable-related concepts specifically
python top_concepts.py --min-books 3       # only concepts in 3+ books
```

A data-grounded alternative to browsing the knowledge map's dropdown
manually — book count is a real signal from your library (how many books
actually touch this concept), not an LLM's impression of what's
important. Useful for finding concrete, library-grounded candidates
before asking a "top N" style question — e.g. run `--search parable`
first to see which named parables your commentaries actually discuss
and how often, then ask `query.py` about those specific ones instead of
trusting a one-shot "top 3" judgment call.

## 9. Generate the book-to-book relationship map

```bash
cd src
python book_map.py
python book_map.py --threshold 0.7   # looser matching, more connections
python book_map.py --threshold 0.85  # stricter matching, fewer connections
```

**Two visual styles**, chosen with `--style`:
- **`columns` (default)** — an interactive two-column map. Loads showing
  all books, but a dropdown at the top lets you pick one book and
  instantly filter down to just that book and its direct connections —
  select "John" and see only the books it actually links to, instead of
  the whole library at once. All filtering happens live in your browser
  (the graph data is embedded in the page), so it's still one
  self-contained HTML file — no server needed.
- **`network`** — the original force-directed graph (`--style network`),
  still available if you want to compare or prefer it for a small,
  loosely-related set of books.

Nodes are **books**, not concepts. An edge is drawn between two books
when their concepts are *semantically* similar — using embedding
similarity rather than exact text match — so "Divinity of Christ" and
"Christ's Divine Nature" from two different books' independent extractions
will correctly connect. Hovering any line or box shows details. Writes to
`library/book_map.html` by default. Concept embeddings are cached in
`library/concept_embedding_cache.json`, so re-running this after adding
more books only costs embedding time for the new concepts.

**If the map looks like an unreadable "hairball"** — this happens with a
thematically homogeneous library (a whole Bible split into 66 books is
the extreme case: every book IS genuinely related to every other, so
showing every true connection at once is too much). The fix isn't a
higher threshold — it's capping how many connections each book can show:

```bash
python book_map.py --max-edges 2   # sparser, only the strongest links
python book_map.py --max-edges 8   # denser, if it looks too sparse
python book_map.py --max-edges 0   # disable pruning entirely
```

This keeps each book's strongest connections and drops the rest, rather
than trying to show every relationship that clears the similarity bar.

**To map just a subset of your library** — e.g. only the KJV Bible books,
excluding your other commentaries and translations:

```bash
python book_map.py --publisher KJV
```

`import_bible_json.py` stores whatever you passed as `--version` in each
book's `publisher` field, so this filters down to just that translation.
You can also filter by title:

```bash
python book_map.py --title Psalm   # just books with "Psalm" in the title
```

Combine filters and pruning as needed, e.g. `python book_map.py
--publisher KJV --max-edges 3` for a focused, readable map of just your
KJV import.

**For labeled edges** — showing *how* two books relate directly on the
graph (like "shares theme: grace"), instead of a plain line you have to
hover over:

```bash
python book_map.py --publisher KJV --max-edges 2 --label-edges
python book_map.py --publisher KJV --max-edges 2 --label-edges --cloud
```

This makes one LLM call per edge shown, so it takes noticeably longer
than the default — combine with a low `--max-edges` to keep the number
of edges (and therefore LLM calls) manageable. `--cloud` uses Anthropic's
API for the labeling step specifically; embeddings/similarity search
always stay local either way.

**Output filenames are now filter-aware** — running `--publisher KJV`
writes to `book_map_kjv.html` automatically, so it won't silently
overwrite your full-library `book_map.html`. Override with `--output`
if you want a specific filename instead.

## 10. Ask questions across your library

```bash
cd src
python query.py "How do these authors define willpower differently?"

# Use the larger model for a harder synthesis question:
python query.py --deep "Trace how these books' views on habit formation evolved"
```

`query.py` now routes a question one of four ways automatically:
- **Names a book + a chapter** ("Summarize John chapter 1") → summarizes
  that chapter's actual text, then separately searches your *other*
  books for related commentary/facts/stories on the same passage, and
  presents both — the source text and what your library adds around it.
  Falls back to a whole-book-scoped search if that chapter isn't found
  under that exact naming (check with `list_chapters.py` if this happens).
- **Names a book + asks for a summary, no chapter** ("Summarize the
  Gospel of John") → returns that book's stored summary + concepts
  directly, skipping chunk search entirely.
- **Names a book, not a summary ask** ("What does the Gospel of John say
  about love?") → chunk search scoped to just that book.
- **No specific book named** → normal cross-library search and synthesis.

You'll see `(matched book: ...)` or `(found chapter ...)` printed so it's
obvious which path ran.

**If answers were getting cut off mid-sentence:** this was a real bug,
now fixed. The cloud path had `max_tokens` hardcoded to 2000 (Claude
Sonnet 5 actually supports up to 128k), and local calls never explicitly
set a generation limit, leaving it up to each model's own default (some
default as low as 128 tokens). Both are now fixed via `LOCAL_NUM_PREDICT`
and `CLOUD_MAX_TOKENS` in `.env` — defaults are generous, but raise them
further if you still see truncation on very long answers.

**Named lookups — for phrases that keep missing semantic search:**
`library/lookups/*.json` maps common names/phrases to an exact book +
chapter, checked *before* semantic search. `python query.py "the parable
of the lost coin"` used to depend on search recall finding Luke 15 among
your whole library; now it routes there directly, guaranteed, because
it's a known name rather than a guess.

Comes with 8 pre-built lookup files covering ~360 aliases total:
- **`parables.json`** — ~30 parables of Jesus
- **`miracles.json`** — ~20 miracles of Jesus
- **`famous_passages.json`** — passages known by nickname (the Beatitudes,
  the Love Chapter, the Ten Commandments, etc.)
- **`old_testament_stories.json`** — ~55 well-known OT narrative events,
  Creation through Jonah
- **`gospel_events.json`** — major events in Jesus's life beyond
  parables/miracles (the Nativity, Baptism, Transfiguration, Crucifixion,
  Resurrection, etc.)
- **`acts_and_epistles.json`** — key events in Acts, plus a few
  well-known epistle passages
- **`key_prophecies.json`** — major Old Testament messianic prophecies,
  useful for cross-referencing prophecy with New Testament fulfillment
- **`characters.json`** — ~44 major biblical figures (Adam, Moses, David,
  Peter, Paul, and more), each spanning several chapters rather than one

Add your own `.json` file in `library/lookups/` for anything else. Two
schemas, depending on whether the thing lives in one chapter or several:

**One exact chapter** (parables, single events):
```json
{
  "description": "what this lookup covers",
  "entries": [
    {"aliases": ["lost coin", "parable of the lost coin"], "book": "Luke", "chapter": 15}
  ]
}
```

**Multiple chapters** (people — almost no one's story fits in one
chapter) — use `"chapters"` (a list) instead of `"book"`/`"chapter"`,
plus an optional `"description"` used as background context (fed to the
model as a hint, not repeated as fact — the model is told to ground any
specific claim in the actual retrieved text instead):
```json
{
  "description": "what this lookup covers",
  "entries": [
    {
      "aliases": ["adam", "the first man"],
      "chapters": [
        {"book": "Genesis", "chapter": 2},
        {"book": "Genesis", "chapter": 3},
        {"book": "Genesis", "chapter": 5}
      ],
      "description": "The first human created by God, husband of Eve."
    }
  ]
}
```
- `aliases`: phrases that should trigger this match (checked as
  substrings of your question, case-insensitive) — add as many
  variations as you want.
- `book`/`chapters[].book`: a fragment matched against your books'
  titles (e.g. "Luke" matches a book titled "Luke"). If multiple books
  match, the *shortest* matching title wins — usually the actual
  scriptural book rather than a commentary about it.
- `chapter`/`chapters[].chapter`: the chapter number, matched the same
  way `list_chapters.py` shows chapter titles — verify with that tool if
  a lookup doesn't fire.

All `.json` files in the folder get loaded automatically; no code
changes needed to add more. Several parables/events (the Sower, the
Crucifixion, etc.) appear in multiple Gospels — each file picks one
canonical location per entry rather than all of them; edit the `book`
field if you'd rather it point to a different Gospel's version.

**Save an answer to a file:**
```bash
python query.py --save "Summarize John chapter 1"
python query.py --save results.txt "Summarize John chapter 1"
```
Without a path, saves to `library/answers/<timestamp>_<question-slug>.txt`.
Also available in the web UI — a "Download as .txt" button appears under
every answer.

**Research mode — for broad topics you want to turn into a post:**
```bash
python query.py --research "What does my library say about grace?"
python query.py --research --cloud "What does my library say about grace?"
```
Instead of one search, this expands your question into several related
angles (e.g. a definition angle, a contrast/tension angle, a historical
angle, a practical angle), searches each separately, merges and dedupes
the results, and caps how many passages any single book can contribute —
so one huge source (like a full Bible import) can't crowd out smaller,
more specific books just by having more raw chunks in the index.

**As your library grows, a second cap matters too:** the per-book cap
alone doesn't bound how many *different* books can qualify for a broad
question — a bigger library naturally surfaces more distinct relevant
books, which can balloon the synthesis prompt. `--max-total` (default 40)
caps the total passages sent to the LLM regardless of book count, spread
evenly across every qualifying book via round-robin — not just the
highest-scoring ones, which would recreate the big-source-domination
problem in a different form. Adjust it as your library scales:
```bash
python query.py --research --max-total 60 "..."   # broader coverage, longer prompt
python query.py --research --max-total 25 "..."   # tighter, faster, more focused
```

The output is a blog-ready draft (intro, thematically organized body,
natural conclusion) rather than a Q&A-style answer, with sources listed
as a footnote. Slower than a normal query since it runs several searches
— `--cloud` works with it exactly the same way as the normal mode, for
better synthesis quality on the final draft.

Also available in the web UI's Ask page as a checkbox.
```bash
python query.py --cloud "How do these authors define willpower differently?"
```
Requires an API key from https://console.anthropic.com set as
`ANTHROPIC_API_KEY` in your `.env`, and `pip install anthropic`. This
sends *only* the retrieved excerpts and your question for that one
synthesis call — embeddings, vector search, and reranking stay local
regardless. Everything else about the pipeline stays fully offline;
`--cloud` is a per-query opt-in, not a mode switch. Costs a fraction of a
cent per query at current Anthropic pricing (roughly $0.01-0.05 depending
on model — see `CLOUD_MODEL` in `.env` to change tiers).

**Two cloud providers are supported** — Anthropic (Claude) and OpenAI
(ChatGPT). `CLOUD_PROVIDER` in `.env` sets the default (`anthropic` or
`openai`), with the matching key (`ANTHROPIC_API_KEY` / `OPENAI_API_KEY`)
and model (`CLOUD_MODEL` / `OPENAI_MODEL`). Override per-query with
`--provider` on the CLI, or the dropdown next to the cloud checkbox on
the web UI's Ask and Write a Post pages:
```bash
python query.py --cloud --provider openai "Summarize John chapter 3"
python writepost.py "king david" --provider openai
```
The OpenAI path talks to the REST API directly (no `openai` package to
install). The same privacy shape applies to both providers: only the
retrieved excerpts and your question are sent, per query.

## Notes on scale and hardware (8–12GB VRAM)

- Embeddings and reranking are cheap (well under 1GB VRAM each) — they
  won't compete with the LLM for memory.
- Ollama loads/unloads models automatically, so running the 8B model at
  query time and the 14B model during batch import isn't a manual juggle.
- Qdrant's vector search is CPU-based and scales fine to millions of
  chunks (thousands of books) without needing GPU at all.
- If imports feel slow on a large backlog, that's almost always the LLM
  summarization step, not embedding or chunking — consider dropping
  `LLM_MODEL_DEEP` down to the 8B model if throughput matters more than
  summary quality.

## 10b. Write a post — a dedicated, simpler tool

`query.py` has grown a lot of flags (`--research`, `--format`, `--cloud`,
`--deep`, `--save`...) from all the features layered on over time.
`writepost.py` is a separate, stable tool for the one workflow that
probably matters most day-to-day: turning your library into a blog-ready
post. It reuses the same tested search/synthesis functions as `query.py`
(so there's one source of truth for how retrieval actually works), but
has its own simple interface that won't change just because `query.py`
grows new experimental flags.

```bash
cd src
python writepost.py "king david"
python writepost.py "ruth chapter 3"
python writepost.py "what does my library say about grace"
python writepost.py "king david" --format person_profile   # skip the prompt, use this format
python writepost.py "king david" --local                    # skip cloud, use the local model
python writepost.py "king david" --no-prompt                 # don't ask which format, best-guess it
```

Always checks `library/lookups/` first (a specific chapter or a
person's story) before falling back to a broader research search.
Always uses a format — auto-suggested based on what matched (a single
chapter suggests `bible_chapter_study`, a person spanning several
chapters suggests `person_profile`), or pick one interactively when
prompted. Defaults to the cloud model for quality, since a real post is
worth the fraction of a cent it costs; `--local` opts out. Always saves
the result to a file, same as `query.py --save`.

Also on the web UI as its own **Write a Post** tab — same workflow, a
topic box and a format dropdown instead of CLI flags.

## 11. Optional: local web UI

Everything above works from the command line. If you'd rather click
around in a browser, there's a small local Flask app that wraps the same
underlying functions — it doesn't change how anything works, just gives
you a browsable front end.

```bash
pip install -r ../requirements.txt   # picks up flask + markdown
cd web
python app.py
```

Then open **http://localhost:5000**. Pages:
- **Library** — same info as `list_books.py`, plus recent import job
  activity, clickable through to each book's detail page (summary,
  concepts, chapter list — like `book_report.py` and `list_chapters.py`
  combined)
- **Ask** — a form for `query.py`'s question-answering, with checkboxes
  for the deeper local model or `--cloud`
- **Write a Post** — the dedicated `writepost.py` workflow: a topic box
  and a format dropdown, for turning your library into a blog-ready post
- **History** — every question asked and its answer, from `query_history`
- **Maps** — opens the knowledge map and book-to-book map, with a button
  to regenerate each on demand

This is single-user and local-only — no login, not meant to be exposed
beyond your own machine. **Importing still happens from the command
line** (`pipeline.py --once` / `--watch`) — imports can take many minutes
per book, which doesn't suit a synchronous web request, so that stays a
terminal job; the web UI just shows you the results and lets you browse/
query once books are in.

## 12. Backing up your library

You've now put real time (and GPU hours) into embeddings, summaries, and
concepts — none of that is backed up by default. It all lives in Docker
volumes, which don't survive a `docker compose down -v` or volume
corruption.

```bash
cd src
python backup.py                     # Postgres + Qdrant, into ../backups/
python backup.py --include-library   # also back up covers, original
                                      # EPUB/PDF files, generated maps
```

**Worth knowing:** the import pipeline *moves* original EPUB/PDF files
into `library/` on successful import — that's the only remaining copy
once a book's imported. If you want true disaster recovery of your
original source files, use `--include-library`; without it, you're only
backing up the derived intelligence (text, embeddings, summaries,
concepts, chapters, query history), which is the expensive-to-recreate
part but not the only thing that matters if you no longer have the
original files elsewhere.

**To restore:**
```bash
python restore.py ../backups/backup_20260705_120000.zip
```
This **overwrites** your current Postgres database and Qdrant collection
— it asks for confirmation first. Use `--skip-postgres`, `--skip-qdrant`,
or `--skip-library` to restore only part of a backup.

There's no automatic scheduling here — run `backup.py` manually after a
big import session, or set up a scheduled task/cron job yourself if you
want it automatic.

**Full disaster recovery (a whole new machine, not just restoring data):**
`backup.py`/`restore.py` handle your Postgres + Qdrant data. A complete
rebuild needs a few more things that live outside those volumes:

1. Install Docker Desktop (WSL2 backend, GPU support) and Python on the
   new machine.
2. Get the project code onto the new machine — this `src/`/`web/`/`db/`/
   `docker-compose.yml` folder itself isn't part of any backup.py output.
3. Restore `.env` — either from a backup made with `--include-config`
   (see below), or recreate it from `.env.example` plus your own notes
   (your Anthropic API key, any custom settings).
4. `docker compose up -d` — this pulls fresh Postgres/Qdrant/Ollama
   images from their public registries automatically (needs internet).
   You don't need to manually save/rebuild these images yourself.
5. Re-pull your Ollama models — **not covered by `backup.py`** (only
   the Postgres/Qdrant volumes are backed up, not `ollama_data`):
   ```bash
   docker exec book_intel_ollama ollama pull nomic-embed-text
   docker exec book_intel_ollama ollama pull qwen3:8b
   docker exec book_intel_ollama ollama pull qwen3:14b
   ```
6. `pip install -r requirements.txt` in a fresh venv.
7. `python restore.py <your-backup.zip>` to load your books/chunks/
   concepts/vectors back in.
8. `python list_books.py` to confirm everything came back.

**To fold your `.env` and `docker-compose.yml` into the backup itself**
(recommended if you want one file that covers as much as possible):
```bash
python backup.py --include-config --include-library
```
This puts your API key into the backup zip — store it somewhere secure
(not a public/shared location) if you use this flag.

## What's NOT handled here (by design, for now)

- PDFs — you said EPUB-first, so this pipeline only watches for `.epub`.
  The parsing module is isolated (`epub_parser.py`) specifically so a
  `pdf_parser.py` can be added later without touching the rest of the
  pipeline.
- DRM removal — if any EPUBs are DRM-protected (common with
  Kindle/Kobo/Adobe purchases), `parse_epub` will raise "No extractable
  text found" and the job will be marked failed rather than silently
  producing garbage.
- Triggering imports from the web UI — importing is a long-running,
  multi-minute-per-book job, which doesn't suit a synchronous web
  request. The web UI is for browsing/querying; imports stay a terminal
  job via `pipeline.py`.
