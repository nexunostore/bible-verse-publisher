"""EPUB import pipeline.

Usage:
    python pipeline.py --once        # scan INCOMING_DIR once, process all EPUBs, exit
    python pipeline.py --watch       # watch INCOMING_DIR continuously

Each file goes through: hash -> dedupe check -> parse -> extract cover ->
chunk (chapter-aware) -> embed (Ollama) -> store vectors (Qdrant) ->
store metadata/text (Postgres) -> summarize (Ollama) -> mark complete.

The core "given parsed metadata + chapters, do everything downstream"
logic lives in import_book_from_parsed() so other importers (e.g.
import_bible_json.py, which reads a structured JSON Bible dump instead
of an EPUB) can reuse the exact same chunking/embedding/storage/
summarization pipeline instead of duplicating it.
"""
import argparse
import hashlib
import os
import shutil
import time
import traceback

from qdrant_client.models import PointStruct
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from db import (CFG, book_exists_by_hash, create_job, get_conn, get_qdrant,
                 ensure_qdrant_collection, insert_book, insert_chapters,
                 insert_chunks, save_book_authors, save_book_concepts,
                 update_book, update_job, upsert_points_batched)
from epub_parser import parse_epub
from chunker import chunk_chapters
from llm import embed_texts, extract_concepts, summarize_book


def sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def import_book_from_parsed(parsed: dict, sha256: str, source_path: str,
                             source_format: str = "epub", cover_bytes: bytes = None) -> bool:
    """Shared downstream pipeline used by every importer: dedupe check,
    store metadata/chapters, chunk, embed, upload vectors, summarize,
    extract concepts. `parsed` must be {"metadata": {...}, "chapters": [...]}
    with chapters as [{"index", "title", "text"}, ...] — exactly what
    epub_parser.parse_epub() and import_bible_json.py both produce.

    Returns True on success, False on duplicate/failure (details printed).
    """
    conn = get_conn()
    qdrant = get_qdrant()
    ensure_qdrant_collection(qdrant)

    meta = parsed["metadata"]
    chapters = parsed["chapters"]
    title = meta.get("title") or os.path.basename(source_path)

    job_id = create_job(conn, source_path, sha256)

    try:
        existing = book_exists_by_hash(conn, sha256)
        if existing:
            print(f"    Duplicate of existing book: {existing['title']!r} — skipping")
            update_job(conn, job_id, stage="done", status="duplicate")
            return False

        if not chapters:
            raise ValueError("No extractable chapters/text found")

        print(f"    Title: {title!r}  Author: {meta.get('author')!r}  Chapters: {len(chapters)}")

        cover_path = None
        if cover_bytes:
            os.makedirs(CFG.covers_dir, exist_ok=True)
            cover_path = os.path.join(CFG.covers_dir, f"{sha256}.jpg")
            with open(cover_path, "wb") as f:
                f.write(cover_bytes)

        book_id = insert_book(conn, sha256, meta, source_path, cover_path, source_format=source_format)
        if meta.get("author"):
            save_book_authors(conn, book_id, [meta["author"]])
        insert_chapters(conn, book_id, chapters)
        update_job(conn, job_id, stage="chunking", book_id=book_id)

        chunks = chunk_chapters(chapters, CFG.chunk_target_words, CFG.chunk_overlap_words)
        print(f"    Created {len(chunks)} chunks")

        update_job(conn, job_id, stage="embedding")
        vectors = embed_texts([c["text"] for c in chunks], show_progress=True)
        chunk_ids = insert_chunks(conn, book_id, chunks, embedding_model=CFG.embed_model)

        points = [
            PointStruct(
                id=cid,
                vector=vec,
                payload={
                    "book_id": book_id,
                    "title": title,
                    "author": meta.get("author"),
                    "chapter_title": chunk["chapter_title"],
                    "chunk_index": chunk["chunk_index"],
                    "text": chunk["text"],
                },
            )
            for cid, vec, chunk in zip(chunk_ids, vectors, chunks)
        ]
        print(f"    Uploading {len(points)} vectors to Qdrant (batched)...")
        upsert_points_batched(qdrant, CFG.qdrant_collection, points)

        update_job(conn, job_id, stage="summarizing")
        try:
            summary = summarize_book(title, meta.get("author"), chapters)
        except Exception as e:
            print(f"    (summary generation failed, continuing without it: {e})")
            summary = None

        update_job(conn, job_id, stage="extracting_concepts")
        try:
            concepts = extract_concepts(title, meta.get("author"), chapters)
            if concepts:
                save_book_concepts(conn, book_id, concepts)
                print(f"    Extracted {len(concepts)} major concepts/themes")
            else:
                print("    (no concepts extracted — local LLM output didn't parse as JSON)")
        except Exception as e:
            print(f"    (concept extraction failed, continuing without it: {e})")

        update_book(conn, book_id, status="complete", summary=summary)
        update_job(conn, job_id, stage="done", status="complete")
        print(f"    Done: {title}")
        return True

    except Exception as e:
        traceback.print_exc()
        update_job(conn, job_id, stage="failed", status="failed", error_message=str(e))
        return False
    finally:
        conn.close()


def process_epub(path: str):
    filename = os.path.basename(path)
    print(f"\n[+] Processing {filename}")
    sha256 = sha256_of_file(path)

    conn = get_conn()
    existing = book_exists_by_hash(conn, sha256)
    conn.close()
    if existing:
        print(f"    Duplicate of existing book: {existing['title']!r} — skipping")
        os.makedirs(CFG.duplicates_dir, exist_ok=True)
        shutil.move(path, os.path.join(CFG.duplicates_dir, filename))
        return

    try:
        parsed = parse_epub(path)
    except Exception as e:
        print(f"    Failed to parse EPUB: {e}")
        traceback.print_exc()
        return

    success = import_book_from_parsed(
        parsed, sha256, path, source_format="epub", cover_bytes=parsed.get("cover")
    )

    if success:
        os.makedirs(CFG.library_dir, exist_ok=True)
        final_path = os.path.join(CFG.library_dir, filename)
        shutil.move(path, final_path)
        conn = get_conn()
        book = book_exists_by_hash(conn, sha256)
        if book:
            update_book(conn, book["id"], source_path=final_path)
        conn.close()


def scan_once():
    os.makedirs(CFG.incoming_dir, exist_ok=True)
    epubs = [f for f in os.listdir(CFG.incoming_dir) if f.lower().endswith(".epub")]
    print(f"Found {len(epubs)} EPUB(s) in {CFG.incoming_dir}")
    for name in epubs:
        process_epub(os.path.join(CFG.incoming_dir, name))


class _Handler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory or not event.src_path.lower().endswith(".epub"):
            return
        time.sleep(1.0)
        process_epub(event.src_path)


def watch():
    os.makedirs(CFG.incoming_dir, exist_ok=True)
    print(f"Watching {CFG.incoming_dir} for new EPUBs... (Ctrl+C to stop)")
    scan_once()
    observer = Observer()
    observer.schedule(_Handler(), CFG.incoming_dir, recursive=False)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--once", action="store_true", help="Scan incoming dir once and exit")
    group.add_argument("--watch", action="store_true", help="Watch incoming dir continuously")
    args = parser.parse_args()

    if args.once:
        scan_once()
    else:
        watch()
