"""List books currently in the library.

Usage:
    python list_books.py                    # everything
    python list_books.py --status complete  # only completed imports
    python list_books.py --status failed    # see what failed and why
"""
import argparse

from db import get_conn


def fetch_books(conn, status: str = None):
    query = """
        SELECT b.title, b.author, b.status, b.source_format, b.created_at,
               b.error_message,
               (SELECT count(*) FROM chunks c WHERE c.book_id = b.id) AS chunk_count,
               (SELECT count(*) FROM book_concepts bc WHERE bc.book_id = b.id) AS concept_count
        FROM books b
    """
    params = []
    if status:
        query += " WHERE b.status = %s"
        params.append(status)
    query += " ORDER BY b.created_at DESC"

    with conn.cursor() as cur:
        cur.execute(query, params)
        return cur.fetchall()


def print_books(rows):
    if not rows:
        print("No books found.")
        return

    print(f"\n{'Title':<45} {'Author':<25} {'Status':<12} {'Chunks':>7} {'Concepts':>9}")
    print("-" * 102)
    for title, author, status, fmt, created, error, chunks, concepts in rows:
        title_disp = (title or "(untitled)")[:44]
        author_disp = (author or "(unknown)")[:24]
        print(f"{title_disp:<45} {author_disp:<25} {status:<12} {chunks:>7} {concepts:>9}")
        if status == "failed" and error:
            print(f"    ↳ {error}")
    print(f"\n{len(rows)} book(s)\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--status", choices=["pending", "processing", "complete", "failed", "duplicate"],
                         help="Only show books with this status")
    args = parser.parse_args()

    conn = get_conn()
    rows = fetch_books(conn, args.status)
    conn.close()
    print_books(rows)
