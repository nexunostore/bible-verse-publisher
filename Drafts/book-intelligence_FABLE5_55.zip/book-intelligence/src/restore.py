"""Restore from a backup created by backup.py.

Usage:
    python restore.py ../backups/backup_20260704_120000.zip
    python restore.py backup.zip --yes            # skip confirmation
    python restore.py backup.zip --skip-library    # don't restore library/
                                                    # even if it's in the backup

This OVERWRITES your current Postgres database and Qdrant collection.
Confirms before doing anything destructive unless --yes is passed.
"""
import argparse
import json
import os
import shutil
import subprocess
import tempfile
import zipfile

from db import CFG, get_qdrant

POSTGRES_CONTAINER = "book_intel_postgres"
POSTGRES_USER = "bookintel"
POSTGRES_DB = "bookintel"


def restore_postgres(staging_dir: str):
    sql_path = os.path.join(staging_dir, "postgres_dump.sql")
    if not os.path.exists(sql_path):
        print("  No postgres_dump.sql found in backup — skipping Postgres restore.")
        return
    print("Restoring Postgres database (this overwrites current data)...")
    with open(sql_path, "rb") as f:
        result = subprocess.run(
            ["docker", "exec", "-i", POSTGRES_CONTAINER, "psql",
             "-U", POSTGRES_USER, "-d", POSTGRES_DB],
            stdin=f, capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
    if result.returncode != 0:
        raise RuntimeError(f"psql restore failed: {result.stderr}")
    print("  Postgres restored")


def restore_qdrant(staging_dir: str):
    snapshot_files = [f for f in os.listdir(staging_dir) if f.endswith(".snapshot")]
    if not snapshot_files:
        print("  No .snapshot file found in backup — skipping Qdrant restore.")
        return
    snapshot_path = os.path.join(staging_dir, snapshot_files[0])
    print(f"Restoring Qdrant collection from {snapshot_files[0]}...")

    import requests
    url = f"{CFG.qdrant_url}/collections/{CFG.qdrant_collection}/snapshots/upload?priority=snapshot"
    with open(snapshot_path, "rb") as f:
        resp = requests.post(url, files={"snapshot": (snapshot_files[0], f)}, timeout=600)
    resp.raise_for_status()
    print("  Qdrant collection restored")


def restore_library(staging_dir: str):
    library_backup = os.path.join(staging_dir, "library")
    if not os.path.isdir(library_backup):
        print("  No library/ folder in this backup — skipping.")
        return
    library_dst = os.path.join(os.path.dirname(__file__), "..", "library")
    print(f"Restoring library/ to {os.path.abspath(library_dst)} (merging, existing files kept)...")
    shutil.copytree(library_backup, library_dst, dirs_exist_ok=True)
    print("  library/ restored")


def restore_config(staging_dir: str):
    config_backup = os.path.join(staging_dir, "config")
    if not os.path.isdir(config_backup):
        print("  No config/ folder in this backup — skipping.")
        return
    project_root = os.path.join(os.path.dirname(__file__), "..")
    print(f"Restoring config files to {os.path.abspath(project_root)}...")
    for fname in os.listdir(config_backup):
        dst = os.path.join(project_root, fname)
        if os.path.exists(dst):
            print(f"  {fname} already exists — NOT overwriting (remove it first if you "
                  f"want the backed-up version restored)")
            continue
        shutil.copy2(os.path.join(config_backup, fname), dst)
        print(f"  restored {fname}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("backup_zip", help="Path to a backup zip created by backup.py")
    parser.add_argument("--yes", action="store_true", help="Skip the confirmation prompt")
    parser.add_argument("--skip-postgres", action="store_true")
    parser.add_argument("--skip-qdrant", action="store_true")
    parser.add_argument("--skip-library", action="store_true")
    parser.add_argument("--skip-config", action="store_true")
    args = parser.parse_args()

    if not os.path.exists(args.backup_zip):
        print(f"Backup file not found: {args.backup_zip}")
        raise SystemExit(1)

    staging_dir = tempfile.mkdtemp(prefix="book_intel_restore_")
    try:
        with zipfile.ZipFile(args.backup_zip) as zf:
            zf.extractall(staging_dir)

        manifest_path = os.path.join(staging_dir, "manifest.json")
        manifest = {}
        if os.path.exists(manifest_path):
            with open(manifest_path) as f:
                manifest = json.load(f)
            print(f"Backup created: {manifest.get('created_at', 'unknown')}")
            print(f"Includes library: {manifest.get('includes_library', False)}")
            print(f"Includes config: {manifest.get('includes_config', False)}")

        print("\nThis will OVERWRITE your current Postgres database and Qdrant collection.")
        if not args.yes:
            confirm = input("Continue? [y/N] ")
            if confirm.strip().lower() != "y":
                print("Cancelled.")
                raise SystemExit(0)

        if not args.skip_postgres:
            restore_postgres(staging_dir)
        if not args.skip_qdrant:
            restore_qdrant(staging_dir)
        if not args.skip_library and manifest.get("includes_library"):
            restore_library(staging_dir)
        if not args.skip_config and manifest.get("includes_config"):
            restore_config(staging_dir)

        print("\nRestore complete.")
    finally:
        shutil.rmtree(staging_dir, ignore_errors=True)
