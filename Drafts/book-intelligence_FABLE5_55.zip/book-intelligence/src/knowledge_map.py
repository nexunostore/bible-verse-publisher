"""Build a knowledge map: concepts as nodes, edges connecting concepts that
co-occur in the same book(s). Renders to a local interactive HTML file
(open it in any browser — no server, no network needed).

Usage:
    python knowledge_map.py                       # all books
    python knowledge_map.py --output map.html      # custom output path
    python knowledge_map.py --min-books 2          # only show concepts
                                                     # appearing in 2+ books
    python knowledge_map.py --style network        # original physics graph
                                                     # instead of the default
                                                     # interactive dropdown view
"""
import argparse
from collections import defaultdict

import networkx as nx
from pyvis.network import Network

from db import get_conn
from map_render import render_interactive_map


def fetch_rows(conn):
    with conn.cursor() as cur:
        cur.execute(
            """SELECT b.id, b.title, b.author, c.id, c.name, bc.importance
               FROM book_concepts bc
               JOIN books b ON b.id = bc.book_id
               JOIN concepts c ON c.id = bc.concept_id"""
        )
        return cur.fetchall()


def build_graph(rows, min_books: int = 1) -> nx.Graph:
    concept_name = {}
    concept_books = defaultdict(set)          # concept_id -> {(book_id, title)}
    concept_importances = defaultdict(list)

    for book_id, title, _author, concept_id, name, importance in rows:
        concept_name[concept_id] = name
        concept_books[concept_id].add((book_id, title))
        if importance:
            concept_importances[concept_id].append(importance)

    graph = nx.Graph()
    for cid, name in concept_name.items():
        freq = len(concept_books[cid])
        if freq < min_books:
            continue
        importances = concept_importances[cid]
        avg_importance = sum(importances) / len(importances) if importances else 3
        titles = ", ".join(sorted(t for _, t in concept_books[cid]))
        graph.add_node(
            cid,
            label=name,
            size=12 + freq * 8,
            title=f"{name}\nAppears in {freq} book(s): {titles}\nAvg importance: {avg_importance:.1f}/5",
        )

    node_ids = list(graph.nodes)
    for i in range(len(node_ids)):
        for j in range(i + 1, len(node_ids)):
            a, b = node_ids[i], node_ids[j]
            shared = concept_books[a] & concept_books[b]
            if shared:
                titles = ", ".join(sorted(t for _, t in shared))
                graph.add_edge(a, b, value=len(shared), title=f"Both appear in: {titles}")

    return graph


def render_columns(graph: nx.Graph, output_path: str):
    """Interactive map — a dropdown lets you pick one concept (e.g.
    "Grace") and instantly see just the other concepts it co-occurs with
    in the same book(s), instead of the whole concept graph at once."""
    nodes_data = [
        {"id": str(n), "label": graph.nodes[n]["label"], "tooltip": graph.nodes[n].get("title", "")}
        for n in graph.nodes
    ]
    edges_data = [
        {"source": str(u), "target": str(v), "label": "",
         "tooltip": data.get("title", "related").replace("\n", " | ")}
        for u, v, data in graph.edges(data=True)
    ]
    render_interactive_map(nodes_data, edges_data, output_path,
                           page_title="Knowledge Map", item_label="concept")


def render_network(graph: nx.Graph, output_path: str):
    net = Network(height="900px", width="100%", bgcolor="#111827",
                  font_color="#e5e7eb", cdn_resources="local")
    net.from_nx(graph)
    net.repulsion(node_distance=180, spring_length=200)
    net.write_html(output_path, notebook=False)
    print(f"Knowledge map (network style) written to {output_path} — open it in a browser.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="../library/knowledge_map.html")
    parser.add_argument("--min-books", type=int, default=1,
                         help="Only include concepts appearing in at least this many books")
    parser.add_argument("--style", choices=["columns", "network"], default="columns",
                         help="'columns' (default): interactive dropdown to focus on one "
                              "concept and see just its connections. 'network': the original "
                              "physics-simulated graph, showing everything at once.")
    args = parser.parse_args()

    conn = get_conn()
    rows = fetch_rows(conn)
    conn.close()

    if not rows:
        print("No concepts found yet. Run the import pipeline first "
              "(pipeline.py --once / --watch) so books have concepts extracted.")
    else:
        graph = build_graph(rows, min_books=args.min_books)
        if graph.number_of_nodes() == 0:
            print(f"No concepts meet --min-books {args.min_books}. Try lowering it.")
        else:
            if args.style == "columns":
                render_columns(graph, args.output)
            else:
                render_network(graph, args.output)
            print(f"{graph.number_of_nodes()} concept nodes, {graph.number_of_edges()} connections.")
