"""See exactly how a book's chapters got captured — useful for checking
whether something like "John 1" exists as its own chapter entry, or
whether the whole Gospel of John landed as one big section.

Usage:
    python list_chapters.py "holy bible"
"""
import argparse

import psycopg2.extras

from db import get_conn


def find_book(conn, title_query: str):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            "SELECT id, title, author FROM books WHERE title ILIKE %s ORDER BY updated_at DESC LIMIT 1",
            (f"%{title_query}%",),
        )
        return cur.fetchone()


def list_chapters(conn, book_id: str):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            "SELECT chapter_index, title, word_count FROM chapters WHERE book_id = %s ORDER BY chapter_index",
            (book_id,),
        )
        return cur.fetchall()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("title", help="Partial book title to look up")
    args = parser.parse_args()

    conn = get_conn()
    book = find_book(conn, args.title)
    if not book:
        print(f"No book found matching {args.title!r}")
    else:
        chapters = list_chapters(conn, book["id"])
        print(f"\n{book['title']} by {book.get('author') or 'Unknown'} — {len(chapters)} chapter(s)\n")
        for c in chapters:
            print(f"  [{c['chapter_index']:>4}] {c['title']}  ({c['word_count']} words)")
    conn.close()
