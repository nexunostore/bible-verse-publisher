"""Thin client around the local Ollama server for embeddings + chat/summaries.

Everything here talks to http://localhost:11434 (or OLLAMA_URL) — no
external network calls once the models have been `ollama pull`-ed.
"""
import re

import requests
from tqdm import tqdm

from db import CFG


def embed_texts(texts: list[str], model: str = None, show_progress: bool = False,
                 batch_size: int = 32) -> list[list[float]]:
    model = model or CFG.embed_model
    try:
        return _embed_batched(texts, model, batch_size, show_progress)
    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            print("(note: batch embedding endpoint not available on this Ollama "
                  "version — falling back to one-at-a-time, which is slower. "
                  "Consider updating Ollama.)")
            return _embed_one_at_a_time(texts, model, show_progress)
        raise


def _embed_batched(texts: list[str], model: str, batch_size: int, show_progress: bool) -> list[list[float]]:
    """Ollama's newer /api/embed endpoint accepts a list of inputs in one
    request, instead of one HTTP round-trip per chunk. For a book with
    thousands of chunks this is the difference between one request per
    ~32 chunks and one request per single chunk — a large chunk of import
    time was going to per-request overhead, not actual model inference."""
    vectors = []
    batches = [texts[i:i + batch_size] for i in range(0, len(texts), batch_size)]
    iterator = tqdm(batches, desc="Embedding (batched)") if show_progress else batches
    for batch in iterator:
        resp = requests.post(
            f"{CFG.ollama_url}/api/embed",
            json={"model": model, "input": batch, "keep_alive": CFG.ollama_keep_alive},
            timeout=180,
        )
        resp.raise_for_status()
        vectors.extend(resp.json()["embeddings"])
    return vectors


def _embed_one_at_a_time(texts: list[str], model: str, show_progress: bool) -> list[list[float]]:
    """Fallback for Ollama versions without /api/embed."""
    vectors = []
    iterator = tqdm(texts, desc="Embedding") if show_progress else texts
    for text in iterator:
        resp = requests.post(
            f"{CFG.ollama_url}/api/embeddings",
            json={"model": model, "prompt": text, "keep_alive": CFG.ollama_keep_alive},
            timeout=120,
        )
        resp.raise_for_status()
        vectors.append(resp.json()["embedding"])
    return vectors


_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)


def _strip_thinking(text: str) -> str:
    """qwen3-style reasoning models wrap internal deliberation in
    <think>...</think> tags before the actual answer. Without stripping,
    local answers look like rambling nonsense (the model 'thinking out
    loud'), and in the worst case the whole response is one giant
    unclosed think block with no real answer at all. Cloud models don't
    do this — which is why --cloud looked fine while local looked broken."""
    text = _THINK_RE.sub("", text)
    if "<think>" in text:
        # Generation ended mid-think (unclosed tag) — nothing after it is
        # a real answer, so drop from the tag onward.
        text = text.split("<think>")[0]
    return text.strip()


def chat(prompt: str, model: str = None, system: str = None, stream: bool = False,
         use_cloud=False) -> str:
    """use_cloud accepts False (local), True (default cloud provider from
    CLOUD_PROVIDER in .env), or a provider name string: "anthropic" /
    "openai". A string is truthy, so it flows through every existing
    `if use_cloud:` / `stream=not use_cloud` check in the codebase
    unchanged — no signature changes needed anywhere else."""
    if use_cloud:
        provider = use_cloud if isinstance(use_cloud, str) else CFG.cloud_provider
        if provider == "openai":
            return _chat_openai(prompt, system=system)
        return _chat_cloud(prompt, system=system)

    model = model or CFG.llm_fast
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    resp = requests.post(
        f"{CFG.ollama_url}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": stream,
            "keep_alive": CFG.ollama_keep_alive,
            # Ask Ollama to disable reasoning/thinking mode entirely for
            # models that support it (qwen3 etc.) — faster, and no tokens
            # wasted on deliberation. Older Ollama versions ignore unknown
            # fields, and _strip_thinking below covers those anyway.
            "think": False,
            "options": {"num_predict": CFG.local_num_predict, "num_ctx": CFG.local_num_ctx},
        },
        timeout=600,
        stream=stream,
    )
    resp.raise_for_status()

    if not stream:
        return _strip_thinking(resp.json()["message"]["content"])

    # Streamed response: print as it arrives, return full text at the end.
    # Printing is filtered through _strip_thinking incrementally, so think
    # blocks never appear in the live output either (which matters for the
    # web UI — it captures these prints as the displayed answer). The
    # _safe_display_len guard handles a "<think>" tag split across chunk
    # boundaries: text that could still turn out to be the start of a tag
    # is held back until enough has arrived to know either way.
    def _safe_display_len(text: str) -> int:
        tag = "<think>"
        # If the text ends with any partial prefix of "<think>" (e.g. "<thi"),
        # don't display those trailing characters yet.
        for k in range(len(tag) - 1, 0, -1):
            if text.endswith(tag[:k]):
                return len(text) - k
        return len(text)

    full = ""
    printed_len = 0
    for line in resp.iter_lines():
        if not line:
            continue
        import json
        piece = json.loads(line)
        chunk = piece.get("message", {}).get("content", "")
        full += chunk
        displayable = _strip_thinking(full)
        safe_len = _safe_display_len(displayable)
        if safe_len > printed_len:
            print(displayable[printed_len:safe_len], end="", flush=True)
            printed_len = safe_len
    # Flush any held-back tail (e.g. answer legitimately ending in "<")
    final = _strip_thinking(full)
    if len(final) > printed_len:
        print(final[printed_len:], end="", flush=True)
    print()
    return final


def _chat_openai(prompt: str, system: str = None) -> str:
    """OpenAI cloud path. Uses plain requests against the REST API rather
    than the openai package — one less dependency to version-pin (the
    anthropic package's httpx conflict already bit us once)."""
    if not CFG.openai_api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set in .env — add it, or use the "
            "Anthropic provider / a local model instead."
        )
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {CFG.openai_api_key}"},
        json={
            "model": CFG.openai_model,
            "messages": messages,
            # Newer OpenAI models require max_completion_tokens (max_tokens
            # is rejected on the gpt-5 family).
            "max_completion_tokens": CFG.cloud_max_tokens,
        },
        timeout=300,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


def _chat_cloud(prompt: str, system: str = None) -> str:
    """Sends the prompt to Anthropic's API instead of the local Ollama
    model. Only called when explicitly requested via --cloud — this is
    the one place in the whole pipeline that leaves the machine. Nothing
    else (embeddings, chunking, vector search, reranking) is affected."""
    if not CFG.anthropic_api_key:
        raise RuntimeError(
            "Cloud mode needs ANTHROPIC_API_KEY set in your .env file. "
            "Get a key at https://console.anthropic.com"
        )
    try:
        import anthropic
    except ImportError:
        raise RuntimeError("Cloud mode needs the anthropic package: pip install anthropic")

    client = anthropic.Anthropic(api_key=CFG.anthropic_api_key)
    kwargs = {
        "model": CFG.cloud_model,
        "max_tokens": CFG.cloud_max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }
    if system:
        kwargs["system"] = system

    response = client.messages.create(**kwargs)
    text = "".join(block.text for block in response.content if block.type == "text")
    print(text)
    return text


def _parse_json_string_array(raw: str) -> list[str]:
    """Same fence-stripping/fallback logic as _parse_json_array, but for a
    flat list of strings rather than a list of objects."""
    import json
    import re

    text = raw.strip()
    text = re.sub(r"^```(json)?", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text).strip()

    data = None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\[.*\]", text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError:
                data = None

    if not isinstance(data, list):
        return []
    return [str(item).strip() for item in data if str(item).strip()]


def expand_question(question: str, model: str = None, use_cloud: bool = False, n: int = 4) -> list[str]:
    """Breaks a broad question into several distinct search angles, so a
    single embedding search doesn't have to carry the whole burden of a
    wide topic (research mode uses this — one search for "what do my
    books say about grace" will structurally miss most of what's there;
    several angled searches, merged, cover much more ground).
    Falls back to just the original question if parsing fails.
    """
    prompt = (
        f'The user wants a comprehensive answer to: "{question}"\n\n'
        f"Break this into {n} distinct search angles that together would "
        "surface a comprehensive answer — for example a core definition/"
        "explanation, a related contrast or tension, a historical/"
        "contextual angle, and a practical/applied angle (adapt to what "
        "actually fits this specific question). Respond with ONLY a JSON "
        "array of short search phrases (3-8 words each), no commentary, "
        'no markdown fences. Example: ["what is grace theologically", '
        '"grace versus salvation by works", "historical development of '
        'grace doctrine", "grace in everyday practice"]'
    )
    raw = chat(prompt, model=model, use_cloud=use_cloud)
    angles = _parse_json_string_array(raw)
    return angles[:n] if angles else [question]


def _parse_json_array(raw: str) -> list[dict]:
    """Local LLMs often wrap JSON in markdown fences or add stray commentary
    despite instructions not to — this strips fences and falls back to
    regex-extracting the first [...] block if a clean parse fails."""
    import json
    import re

    text = raw.strip()
    text = re.sub(r"^```(json)?", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text).strip()

    data = None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\[.*\]", text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError:
                data = None

    if not isinstance(data, list):
        return []

    cleaned = []
    for item in data:
        if not isinstance(item, dict) or "concept" not in item:
            continue
        raw_importance = item.get("importance", 3)
        try:
            importance = max(1, min(5, int(raw_importance)))
        except (TypeError, ValueError):
            importance = 3
        cleaned.append({
            "concept": str(item.get("concept"))[:200].strip(),
            "description": str(item.get("description", ""))[:1000].strip(),
            "importance": importance,
        })
    return cleaned


def extract_concepts(title: str, author: str, chapters: list[dict],
                      model: str = None, max_concepts: int = None) -> list[dict]:
    """Returns [{concept, description, importance}, ...] — the book's major
    ideas/themes, each with a short note on how this specific book treats it
    and a 1-5 importance rating. This is what powers the cross-book
    knowledge map: concepts get deduped/linked across your whole library.

    max_concepts scales with the book's actual length when not given
    explicitly — LLMs reliably treat "up to N" as a target and pad to hit
    it, so a short book asked for the same cap as a huge one ends up with
    padded/redundant "major themes." Combined with an explicit instruction
    below that fewer is fine, this keeps concept lists proportional to how
    much book is actually there.
    """
    model = model or CFG.llm_deep
    total_words = sum(len(ch["text"].split()) for ch in chapters)
    if max_concepts is None:
        max_concepts = max(5, min(18, total_words // 4000))

    outline = []
    for ch in chapters:
        outline.append(f"## {ch['title']}\n{ch['text'][:500]}")
    outline_text = "\n\n".join(outline)[:24000]

    prompt = (
        f'Below are chapter titles and excerpts from "{title}" '
        f'by {author or "an unknown author"}.\n\n'
        f"{outline_text}\n\n"
        f"Identify up to {max_concepts} major ideas, concepts, or themes this "
        "book genuinely engages with in depth. It is completely fine to "
        f"return fewer than {max_concepts} — do NOT pad the list with minor, "
        "redundant, or overlapping ideas just to hit the maximum. Only "
        "include something if it's actually central to the book, not a "
        "passing mention. Respond with ONLY a JSON array, no markdown "
        "fences, no commentary before or after. Each element must look like:\n"
        '{"concept": "short name, 2-5 words", '
        '"description": "1-2 sentences on how this specific book treats it", '
        '"importance": integer from 1 to 5}'
    )
    raw = chat(prompt, model=model)
    return _parse_json_array(raw)


def summarize_book(title: str, author: str, chapters: list[dict], model: str = None) -> str:
    """Cheap-but-effective book summary: feed chapter titles + a slice of
    each chapter's opening text, rather than the whole book (keeps this
    within a local model's context window regardless of book length).
    """
    model = model or CFG.llm_deep
    outline = []
    for ch in chapters:
        snippet = ch["text"][:600]
        outline.append(f"## {ch['title']}\n{snippet}")
    outline_text = "\n\n".join(outline)
    # Guard against extremely long books blowing the context window
    outline_text = outline_text[:24000]

    prompt = (
        f"Below are the chapter titles and opening excerpts of a book "
        f"titled \"{title}\" by {author or 'an unknown author'}.\n\n"
        f"{outline_text}\n\n"
        "Write a concise 4-6 sentence summary of what this book covers, "
        "its main themes, and its overall argument or narrative arc. "
        "Do not simply list chapter titles."
    )
    return chat(prompt, model=model)
