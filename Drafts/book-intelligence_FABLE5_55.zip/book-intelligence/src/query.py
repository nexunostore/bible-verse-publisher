"""Ask a question across your whole library.

Usage:
    python query.py "How do these authors define willpower differently?"
    python query.py "Summarize the Gospel of John"
    python query.py "Summarize John chapter 1"
    python query.py "What does the Gospel of John say about love?"

Four paths, chosen automatically based on what the question names:
  1. Book + chapter ("Summarize John chapter 1") -> summarize that
     specific chapter's actual text, AND separately search your OTHER
     books for related commentary/facts/stories, then present both.
  2. Book + summary ask, no chapter ("Summarize the Gospel of John") ->
     return that book's stored whole-book summary + concepts directly.
  3. Book named, not a summary ask -> chunk search scoped to that book.
  4. No book named -> normal cross-library search, as before.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime

import psycopg2.extras
from qdrant_client.models import FieldCondition, Filter, MatchValue
from sentence_transformers import CrossEncoder

from db import CFG, get_chunks_for_chapter, get_conn, get_qdrant, log_query
from llm import chat, embed_texts, expand_question

_reranker = None

SUMMARY_KEYWORDS = ("summary", "summarize", "summarise", "overview", "synopsis")
LOOKUPS_DIR = os.path.join(os.path.dirname(__file__), "..", "library", "lookups")


def load_named_lookups() -> tuple[list[dict], dict]:
    """Loads every *.json file in library/lookups/. Returns two things:

    1. A list of alias entries (used for matching questions, as before).
    2. An ID index: {id_string -> entry_data} across ALL files, used
       to resolve cross-references.

    Each JSON entry can optionally include:
    - "id": a unique string (e.g. "evt_david_goliath", "chr_david")
    - "related": a list of IDs from any file (e.g. ["chr_david",
      "proph_nathan_confronts_david"]) — when a lookup matches, the
      system also loads every related entry's chapters and descriptions
      as additional structured context, so a question about a person
      automatically pulls in their specific named events, prophecies,
      etc., not just what semantic search happens to find.

    Both shapes (single "book"+"chapter" and multi "chapters" list)
    still work exactly as before — IDs and related are purely additive.
    """
    entries = []
    id_index = {}
    if not os.path.isdir(LOOKUPS_DIR):
        return entries, id_index

    for fname in sorted(os.listdir(LOOKUPS_DIR)):
        if not fname.endswith(".json"):
            continue
        try:
            with open(os.path.join(LOOKUPS_DIR, fname), "r", encoding="utf-8-sig") as f:
                data = json.load(f)
            for entry in data.get("entries", []):
                if "chapters" in entry:
                    locations = entry["chapters"]
                elif "book" in entry and "chapter" in entry:
                    locations = [{"book": entry["book"], "chapter": entry["chapter"]}]
                else:
                    locations = []

                notes = entry.get("description") or entry.get("notes") or entry.get("event")
                entry_id = entry.get("id")
                related_ids = entry.get("related", [])

                normalized = {
                    "id": entry_id,
                    "locations": locations,
                    "notes": notes,
                    "related": related_ids,
                    "source_file": fname,
                    "aliases_raw": entry.get("aliases", []),
                }

                if entry_id:
                    id_index[entry_id] = normalized

                for alias in entry.get("aliases", []):
                    alias_entry = dict(normalized)
                    alias_entry["alias"] = alias.lower().strip()
                    entries.append(alias_entry)

        except Exception as e:
            print(f"(warning: couldn't load lookup file {fname!r}: {e})", file=sys.stderr)

    entries.sort(key=lambda e: len(e["alias"]), reverse=True)
    return entries, id_index


def resolve_related(match: dict, id_index: dict, max_depth: int = 1,
                     max_items: int = 12) -> list[dict]:
    """Given a matched entry and the ID index, return a list of related
    entries (their locations + notes), following 'related' links one
    level deep (no recursive chains — keeping this simple and
    predictable). Deduplicates by ID.

    max_items caps how many related entries get resolved. Every resolved
    entry costs chapter lookups in answer_named_multi, but the assembled
    related-context is truncated to a few thousand characters anyway —
    so entries past the first dozen are pure fetch cost (heavily-linked
    entries like Jesus carry 400+ links) with zero effect on the answer.
    Lookup files order 'related' most-important-first, so the cap keeps
    exactly the entries that matter most."""
    seen = set()
    if match.get("id"):
        seen.add(match["id"])
    related = []
    for rid in match.get("related", []):
        if len(related) >= max_items:
            break
        if rid in seen:
            continue
        seen.add(rid)
        entry = id_index.get(rid)
        if entry:
            related.append(entry)
    return related


def find_named_reference(question: str, lookups: list[dict]):
    q = question.lower()
    for entry in lookups:
        if entry["alias"] in q:
            return entry
    return None


def find_book_by_fragment(conn, fragment: str):
    """Looks up a book by a plain name fragment (e.g. "Luke"), not the
    fuzzy question-parsing find_matching_book() uses — this is for
    named-lookup entries where we already know the exact book name.
    Shortest matching title wins, since that's usually the actual
    scriptural book rather than a commentary *about* it.

    Normalizes hyphens to spaces before matching: lookup files sometimes
    use a slug-style name (e.g. "1-Samuel", matching
    import_bible_json.py's folder-slug convention) while the actual
    stored book title uses a space (e.g. "1 Samuel", from that same
    script's SLUG_TO_TITLE mapping) — without this, entries for any
    numbered book (1/2 Samuel, 1/2 Kings, 1/2 Corinthians, etc.) would
    silently match zero books.
    """
    normalized_fragment = fragment.replace("-", " ")
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """SELECT id, title, author FROM books
               WHERE status = 'complete' AND title ILIKE %s
               ORDER BY length(title) ASC""",
            (f"%{normalized_fragment}%",),
        )
        return cur.fetchall()


def get_reranker() -> CrossEncoder:
    global _reranker
    if _reranker is None:
        print(f"(loading reranker {CFG.reranker_model} — first run downloads it, "
              f"then it's cached locally)", file=sys.stderr)
        _reranker = CrossEncoder(CFG.reranker_model)
    return _reranker


def _core_title(title: str) -> str:
    core = title.split(":")[0].strip()
    core = re.sub(r"^(the|a|an)\s+", "", core, flags=re.IGNORECASE)
    return re.sub(r"[^\w\s]", "", core).lower().strip()


def find_matching_book(conn, question: str):
    q_clean = re.sub(r"[^\w\s]", "", question.lower())
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT id, title, author, summary FROM books WHERE status = 'complete'")
        books = cur.fetchall()

    best = None
    for book in books:
        if not book["title"]:
            continue
        core = _core_title(book["title"])
        if core and core in q_clean:
            if best is None or len(core) > len(_core_title(best["title"])):
                best = book
    return best


def find_chapter_reference(question: str, book_core: str):
    """Looks for 'chapter N' anywhere, or '<book title> N' (e.g. 'John 1')."""
    q_clean = re.sub(r"[^\w\s]", "", question.lower())
    m = re.search(r"chapter\s+(\d{1,3})\b", q_clean)
    if m:
        return m.group(1)
    if book_core:
        m2 = re.search(re.escape(book_core) + r"\s+(\d{1,3})\b", q_clean)
        if m2:
            return m2.group(1)
    return None


def fetch_book_concepts(conn, book_id: str):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """SELECT c.name, bc.description, bc.importance
               FROM book_concepts bc JOIN concepts c ON c.id = bc.concept_id
               WHERE bc.book_id = %s ORDER BY bc.importance DESC""",
            (book_id,),
        )
        return cur.fetchall()


def answer_from_stored_summary(conn, book: dict) -> str:
    concepts = fetch_book_concepts(conn, book["id"])
    lines = [f"# {book['title']}"]
    if book.get("author"):
        lines.append(f"by {book['author']}")
    lines.append("")
    lines.append(book.get("summary") or "(No summary was generated for this book.)")
    if concepts:
        lines.append("\n**Major themes:**")
        for c in concepts:
            lines.append(f"- {c['name']}" + (f" — {c['description']}" if c.get("description") else ""))
    return "\n".join(lines)


def search(question: str, top_k: int = 40, top_n: int = 12,
           book_id: str = None, exclude_book_id: str = None):
    qdrant = get_qdrant()
    query_vec = embed_texts([question])[0]

    must, must_not = [], []
    if book_id:
        must.append(FieldCondition(key="book_id", match=MatchValue(value=book_id)))
    if exclude_book_id:
        must_not.append(FieldCondition(key="book_id", match=MatchValue(value=exclude_book_id)))
    query_filter = Filter(must=must or None, must_not=must_not or None) if (must or must_not) else None

    hits = qdrant.search(
        collection_name=CFG.qdrant_collection,
        query_vector=query_vec,
        query_filter=query_filter,
        limit=top_k,
    )
    if not hits:
        return []

    pairs = [[question, h.payload["text"]] for h in hits]
    scores = get_reranker().predict(pairs)

    ranked = sorted(zip(hits, scores), key=lambda x: x[1], reverse=True)[:top_n]
    return [
        {
            "chunk_id": h.id,
            "title": h.payload.get("title") or "Unknown title",
            "author": h.payload.get("author") or "Unknown author",
            "chapter_title": h.payload.get("chapter_title"),
            "text": h.payload["text"],
            "score": float(score),
        }
        for h, score in ranked
    ]


def build_context(results: list[dict]) -> str:
    by_book = {}
    for r in results:
        key = f"{r['title']} — {r['author']}"
        by_book.setdefault(key, []).append(r)

    blocks = []
    for book, chunks in by_book.items():
        excerpts = "\n\n".join(
            f"  [Chapter: {c['chapter_title']}]\n  {c['text']}" for c in chunks
        )
        blocks.append(f"### {book}\n{excerpts}")
    return "\n\n".join(blocks)


def answer_chapter(conn, book: dict, chapter_ref: str, question: str, model: str,
                    use_cloud: bool = False, format_instructions: str = None) -> str:
    """Path 1: summarize one specific chapter's actual text, then
    separately pull in related material from the user's OTHER books.

    Without format_instructions: a clean summary + merged study notes,
    not a book-by-book comparison (that framing is right for the general
    cross-library path, but wrong for "give me something blog-ready").

    With format_instructions: a single combined synthesis call using
    your custom structure/style requirements instead of the built-in
    format — same source text + supplementary search, your own template.
    """
    chunks = get_chunks_for_chapter(conn, book["id"], chapter_ref)
    if not chunks:
        print(f"(no chapter matching {chapter_ref!r} found in {book['title']!r} — "
              f"check exact chapter naming with: python list_chapters.py \"{book['title'][:30]}\")\n")
        print("Falling back to a search scoped to the whole book instead.\n")
        results = search(question, book_id=book["id"])
        if not results:
            return "No relevant passages found for this question."
        return _synthesize(question, results, model, use_cloud=use_cloud,
                            format_instructions=format_instructions)

    source_text = "\n\n".join(c["text"] for c in chunks)[:8000]
    chapter_label = chunks[0]["chapter_title"]
    print(f"(found chapter {chapter_label!r} in {book['title']!r} — "
          f"{len(chunks)} chunk(s). Gathering supplementary material from your other books...)\n")

    related = search(question, book_id=None, exclude_book_id=book["id"])
    related_context = build_context(related) if related else "(No related material found in your other books.)"
    sources = sorted({r["title"] for r in related}) if related else []

    if format_instructions:
        prompt = (
            f"SOURCE TEXT — {book['title']}, {chapter_label}:\n{source_text}\n\n"
            f"SUPPLEMENTARY EXCERPTS FROM OTHER BOOKS IN THE LIBRARY:\n{related_context}\n\n"
            f"INSTRUCTIONS FOR THE FINAL DOCUMENT:\n{format_instructions}\n\n"
            "Use only the material above — the source text and the supplementary "
            "excerpts. If the instructions ask for something not actually "
            "supported by this material (specific historical facts, named "
            "sources, anecdotes, etc. that aren't in the excerpts), say plainly "
            "that your library doesn't contain that material rather than "
            "inventing it. Where you do cite something, it should trace back "
            "to a book actually in this library, not general knowledge."
        )
        full_answer = chat(prompt, model=model, stream=not use_cloud, use_cloud=use_cloud)
        if sources:
            full_answer += f"\n\n---\n*Sources consulted: {', '.join(sources)}*"
        return full_answer

    source_summary = chat(
        "Write a clear, flowing summary of the following passage — a few "
        "well-written paragraphs someone could read to understand what "
        "happens/what's said, not a dry outline. Stick to what's actually "
        "here; don't add outside interpretation.\n\n"
        f"{source_text}\n\nSummary:",
        model=model,
        use_cloud=use_cloud,
    )

    if related:
        supplementary = chat(
            f"Below are excerpts from other books in the user's library, related "
            f"to this passage: {question}\n\n{related_context}\n\n"
            "Pull out anything genuinely useful for someone writing a blog post "
            "about this passage: interesting background facts, historical "
            "context, word studies, related stories, or study-guide-style "
            "insights. Write it as flowing prose or a clean list of notes — "
            "merge everything into one coherent set of notes. Do NOT organize "
            "this by source book, do NOT write a book-by-book comparison "
            "(e.g. 'Book A says X, Book B says Y'), and do NOT add a section "
            "about what's missing or where sources overlap — just give the "
            "useful content directly. You can mention a source briefly in "
            "passing if it strengthens a point (e.g. 'one commentary notes...'), "
            "but attribution should never be the organizing structure. If "
            "nothing here is genuinely relevant, say so in one line.",
            model=model,
            use_cloud=use_cloud,
        )
    else:
        supplementary = "(No related material found in your other books for this passage.)"

    result = (
        f"## Summary — {book['title']}, {chapter_label}\n\n{source_summary}\n\n"
        f"## Study Notes & Interesting Facts\n\n{supplementary}"
    )
    if sources:
        result += f"\n\n---\n*Sources consulted: {', '.join(sources)}*"
    return result


def answer_named_multi(conn, named_match: dict, question: str, model: str,
                        use_cloud: bool = False, format_instructions: str = None,
                        id_index: dict = None) -> str:
    """For a named lookup spanning multiple chapters (a person, unlike a
    parable, rarely lives in just one place) — gathers each listed
    chapter's actual text, resolves cross-referenced related entries for
    additional structured context, adds cross-library supplementary
    search on top, and includes background notes as context."""
    locations = named_match["locations"]
    primary_blocks = []
    for loc in locations:
        candidates = find_book_by_fragment(conn, loc["book"])
        if not candidates:
            continue
        book = candidates[0]
        chunks = get_chunks_for_chapter(conn, book["id"], str(loc["chapter"]))
        if chunks:
            text = "\n\n".join(c["text"] for c in chunks)[:4000]
            primary_blocks.append(f"[{book['title']} {loc['chapter']}]\n{text}")

    # Resolve cross-references: pull in related entries' chapters + notes
    related_entries = resolve_related(named_match, id_index or {})
    related_context_blocks = []
    if related_entries:
        print(f"(also loading {len(related_entries)} cross-referenced entries: "
              f"{', '.join(e.get('id','?') for e in related_entries)})\n")
        for rel in related_entries:
            rel_note = rel.get("notes", "")
            rel_label = rel.get("id") or ", ".join(rel.get("aliases_raw", [])[:2])
            for loc in rel.get("locations", []):
                candidates = find_book_by_fragment(conn, loc["book"])
                if not candidates:
                    continue
                book = candidates[0]
                chunks = get_chunks_for_chapter(conn, book["id"], str(loc["chapter"]))
                if chunks:
                    text = "\n\n".join(c["text"] for c in chunks)[:3000]
                    header = f"[Related: {rel_label} — {book['title']} {loc['chapter']}]"
                    if rel_note:
                        header += f"\nContext: {rel_note}"
                    related_context_blocks.append(f"{header}\n{text}")

    if not primary_blocks and not related_context_blocks:
        print(f"(matched named reference {named_match['alias']!r} but couldn't find any of its "
              f"listed chapters in your library — falling through to normal search)\n")
        results = search(question)
        if not results:
            return "No relevant passages found in your library for this question."
        return _synthesize(question, results, model, use_cloud=use_cloud,
                            format_instructions=format_instructions)

    found_count = len(primary_blocks)
    total_count = len(locations)
    print(f"(matched named reference {named_match['alias']!r} — found {found_count} of "
          f"{total_count} listed chapter(s) [from {named_match['source_file']}])\n")

    primary_text = "\n\n".join(primary_blocks)[:12000]
    related_structured = "\n\n".join(related_context_blocks)[:6000] if related_context_blocks else ""

    related = search(question, top_k=40, top_n=12)
    search_context = build_context(related) if related else "(No additional related material found.)"
    sources = sorted({r["title"] for r in related}) if related else []

    background = f"Background note (for identification/context only): {named_match['notes']}\n\n" \
        if named_match.get("notes") else ""

    instructions = format_instructions or (
        "Write a clear, well-organized answer drawing on the primary text and the "
        "supplementary excerpts: who/what this covers, key events, and any notable "
        "themes or significance. Blend supplementary material in naturally; don't "
        "just list book-by-book comparisons."
    )

    related_section = ""
    if related_structured:
        related_section = f"\n\nCROSS-REFERENCED MATERIAL (related events, prophecies, or people):\n{related_structured}\n"

    prompt = (
        f"{background}"
        f"PRIMARY TEXT (from the chapters where this appears):\n{primary_text}\n"
        f"{related_section}\n"
        f"SUPPLEMENTARY EXCERPTS FROM OTHER BOOKS IN THE LIBRARY:\n{search_context}\n\n"
        f"QUESTION: {question}\n\n"
        f"INSTRUCTIONS:\n{instructions}\n\n"
        "Use only the material above. The background note, if present, is for "
        "context/identification only — ground any specific claim in the actual "
        "primary text or excerpts, don't just restate the note as fact. If the "
        "instructions ask for something not supported by this material, say so "
        "rather than inventing it."
    )
    full_answer = chat(prompt, model=model, stream=not use_cloud, use_cloud=use_cloud)
    if sources:
        full_answer += f"\n\n---\n*Sources consulted: {', '.join(sources)}*"
    return full_answer


def _synthesize(question: str, results: list[dict], model: str, use_cloud: bool = False,
                 format_instructions: str = None) -> str:
    context = build_context(results)
    if format_instructions:
        prompt = (
            f"EXCERPTS from the user's personal book library:\n{context}\n\n"
            f"TOPIC: {question}\n\n"
            f"INSTRUCTIONS FOR THE FINAL DOCUMENT:\n{format_instructions}\n\n"
            "Use only the excerpts above. If the instructions ask for something "
            "not actually supported by these excerpts, say plainly that your "
            "library doesn't contain that material rather than inventing it."
        )
    else:
        prompt = (
            "You are analyzing excerpts pulled from the user's personal book library "
            "to answer their question. Excerpts are grouped by source book.\n\n"
            f"EXCERPTS:\n{context}\n\n"
            f"QUESTION: {question}\n\n"
            "Answer the question using only the excerpts above. Where books agree, "
            "say so; where they differ or offer distinct perspectives, compare them "
            "explicitly. Always attribute claims to the specific book/author they "
            "came from. If the excerpts don't fully answer the question, say what's "
            "missing rather than guessing."
        )
    print("--- Answer ---\n")
    return chat(prompt, model=model, stream=not use_cloud, use_cloud=use_cloud)


def answer_research(question: str, model: str, use_cloud: bool = False,
                     max_per_book: int = 4, num_angles: int = 4, max_total: int = 40,
                     format_instructions: str = None) -> str:
    """Broad-topic mode: expands the question into several search angles
    (one embedding search structurally can't cover a wide topic well),
    merges + dedupes results across all of them, caps how many chunks any
    single book can contribute (so one huge source can't crowd out
    smaller, more specific books on raw similarity score alone), caps the
    TOTAL passages sent to the LLM regardless of how many different books
    qualify (a growing library means more distinct books can plausibly
    match a broad question — the per-book cap alone doesn't bound that),
    then writes a blog-ready piece rather than a Q&A-style answer.
    """
    print("(research mode: expanding into multiple search angles...)")
    angles = expand_question(question, model=model, use_cloud=use_cloud, n=num_angles)
    for a in angles:
        print(f"  - {a}")
    print()

    seen_ids = set()
    merged = []
    for angle in angles:
        for r in search(angle, top_k=50, top_n=15):
            if r["chunk_id"] not in seen_ids:
                seen_ids.add(r["chunk_id"])
                merged.append(r)

    if not merged:
        return "No relevant passages found in your library for this topic."

    by_book = {}
    for r in merged:
        by_book.setdefault(r["title"], []).append(r)
    for title in by_book:
        by_book[title].sort(key=lambda r: r["score"], reverse=True)
        by_book[title] = by_book[title][:max_per_book]

    total_after_per_book_cap = sum(len(v) for v in by_book.values())

    if total_after_per_book_cap > max_total:
        # Round-robin across books instead of just taking the top-scoring
        # chunks overall — a flat top-N would just recreate the
        # big-source-domination problem the per-book cap already fixed,
        # since some books' chunks tend to score consistently higher.
        capped = []
        queues = {title: list(items) for title, items in by_book.items()}
        while len(capped) < max_total and any(queues.values()):
            for title in list(queues.keys()):
                if queues[title]:
                    capped.append(queues[title].pop(0))
                    if len(capped) >= max_total:
                        break
        print(f"(gathered {total_after_per_book_cap} passages across {len(by_book)} book(s) "
              f"after per-book cap; kept {len(capped)} spread evenly across all of them "
              f"under the {max_total}-passage total cap)\n")
    else:
        capped = [item for items in by_book.values() for item in items]
        print(f"(gathered {len(capped)} passages across {len(by_book)} book(s) after per-book cap)\n")

    context = build_context(capped)
    if format_instructions:
        prompt = (
            f"TOPIC: {question}\n\n"
            f"Below are relevant excerpts from the user's personal book library, "
            f"gathered from several angles on this topic:\n\n{context}\n\n"
            f"INSTRUCTIONS FOR THE FINAL DOCUMENT:\n{format_instructions}\n\n"
            "Use only the excerpts above. If the instructions ask for something "
            "not actually supported by these excerpts, say plainly that your "
            "library doesn't contain that material rather than inventing it."
        )
    else:
        prompt = (
            f"The user wants to write a blog post about: {question}\n\n"
            f"Below are relevant excerpts from their personal book library, "
            f"gathered from several angles on this topic:\n\n{context}\n\n"
            "Write a well-organized, blog-ready piece drawing on this material: "
            "a natural introduction, a body organized by theme (NOT book-by-"
            "book), and a natural conclusion. Blend insights from across the "
            "sources into flowing prose — do not structure this as 'Book A "
            "says X, Book B says Y.' Mention a source briefly in passing only "
            "where it strengthens a point. Use as much of the relevant "
            "material as genuinely supports the topic; don't pad with "
            "material that's only loosely related."
        )
    print("--- Draft ---\n")
    full_answer = chat(prompt, model=model, stream=not use_cloud, use_cloud=use_cloud)

    sources = sorted(by_book.keys())
    full_answer += f"\n\n---\n*Sources consulted: {', '.join(sources)}*"

    try:
        conn = get_conn()
        log_query(conn, question, model, full_answer,
                   cited=[{"chunk_id": r["chunk_id"], "score": r["score"]} for r in capped])
        conn.close()
    except Exception as e:
        print(f"\n(note: failed to log query history: {e})", file=sys.stderr)

    return full_answer


def answer(question: str, model: str = None, use_cloud: bool = False, format_instructions: str = None) -> str:
    conn = get_conn()
    used_model = model or CFG.llm_fast

    # Named lookups take priority — an exact, curated match beats guessing
    # from regex or hoping semantic search recalls the right passage.
    lookups, id_index = load_named_lookups()
    named_match = find_named_reference(question, lookups)
    if named_match:
        locations = named_match["locations"]

        # Entries carrying 'related' cross-links go through answer_named_multi
        # even when they list only ONE chapter: people.json entries are
        # single-chapter by design, with their breadth living in 'related'
        # links — and answer_chapter never resolves those. Routing on
        # location count alone would silently discard every cross-link.
        if len(locations) == 1 and not named_match.get("related"):
            loc = locations[0]
            candidates = find_book_by_fragment(conn, loc["book"])
            if candidates:
                book = candidates[0]
                print(f"(matched named reference {named_match['alias']!r} -> {loc['book']} "
                      f"chapter {loc['chapter']} [from {named_match['source_file']}])\n")
                full_answer = answer_chapter(conn, book, str(loc["chapter"]), question, used_model,
                                              use_cloud=use_cloud, format_instructions=format_instructions)
                print(full_answer)
                try:
                    log_query(conn, question, used_model, full_answer, cited=[])
                except Exception as e:
                    print(f"\n(note: failed to log query history: {e})", file=sys.stderr)
                conn.close()
                return full_answer
            else:
                print(f"(matched named reference {named_match['alias']!r} but no book matching "
                      f"{loc['book']!r} found in your library — falling through to normal search)\n")
        else:
            full_answer = answer_named_multi(conn, named_match, question, used_model,
                                              use_cloud=use_cloud, format_instructions=format_instructions,
                                              id_index=id_index)
            print(full_answer)
            try:
                log_query(conn, question, used_model, full_answer, cited=[])
            except Exception as e:
                print(f"\n(note: failed to log query history: {e})", file=sys.stderr)
            conn.close()
            return full_answer

    matched_book = find_matching_book(conn, question)
    chapter_ref = find_chapter_reference(question, _core_title(matched_book["title"])) if matched_book else None

    if matched_book and chapter_ref:
        full_answer = answer_chapter(conn, matched_book, chapter_ref, question, used_model,
                                      use_cloud=use_cloud, format_instructions=format_instructions)
        print(full_answer)
        try:
            log_query(conn, question, used_model, full_answer, cited=[])
        except Exception as e:
            print(f"\n(note: failed to log query history: {e})", file=sys.stderr)
        conn.close()
        return full_answer

    # Skip the raw stored-summary shortcut when a custom format is requested —
    # that path has no LLM synthesis step to apply formatting to.
    if matched_book and not format_instructions and any(kw in question.lower() for kw in SUMMARY_KEYWORDS):
        print(f"(matched book: {matched_book['title']!r} — using stored summary, skipping chunk search)\n")
        full_answer = answer_from_stored_summary(conn, matched_book)
        print(full_answer)
        try:
            log_query(conn, question, "stored_summary", full_answer, cited=[])
        except Exception as e:
            print(f"\n(note: failed to log query history: {e})", file=sys.stderr)
        conn.close()
        return full_answer

    book_id = matched_book["id"] if matched_book else None
    if matched_book:
        print(f"(matched book: {matched_book['title']!r} — scoping search to this book)\n")

    results = search(question, book_id=book_id)
    if not results:
        conn.close()
        return "No relevant passages found in your library for this question."

    full_answer = _synthesize(question, results, used_model, use_cloud=use_cloud,
                               format_instructions=format_instructions)
    try:
        log_query(conn, question, used_model, full_answer,
                   cited=[{"chunk_id": r["chunk_id"], "score": r["score"]} for r in results])
    except Exception as e:
        print(f"\n(note: failed to log query history: {e})", file=sys.stderr)
    conn.close()
    return full_answer


def save_answer_to_file(question: str, answer_text: str, path: str = None) -> str:
    """Writes the answer to a .txt file. Without an explicit path, saves
    to library/answers/<timestamp>_<question-slug>.txt."""
    if path is None:
        slug = re.sub(r"[^\w\s-]", "", question.lower())
        slug = re.sub(r"[-\s]+", "-", slug).strip("-")[:50]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        answers_dir = os.path.join(os.path.dirname(__file__), "..", "library", "answers")
        os.makedirs(answers_dir, exist_ok=True)
        path = os.path.join(answers_dir, f"{timestamp}_{slug}.txt")

    with open(path, "w", encoding="utf-8") as f:
        f.write(f"Question: {question}\n{'=' * 60}\n\n{answer_text}\n")
    return os.path.abspath(path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("question", help="Question to ask across your library")
    parser.add_argument("--deep", action="store_true",
                         help="Use the larger/deeper local LLM instead of the fast one")
    parser.add_argument("--cloud", action="store_true",
                         help="Use a cloud model instead of a local one for synthesis "
                              "(sends only the retrieved excerpts + question). Provider "
                              "comes from CLOUD_PROVIDER in .env unless --provider is given.")
    parser.add_argument("--provider", choices=["anthropic", "openai"], default=None,
                         help="Which cloud provider to use with --cloud (overrides "
                              "CLOUD_PROVIDER from .env for this one query)")
    parser.add_argument("--research", action="store_true",
                         help="Broad research mode: expands the question into multiple search "
                              "angles, gathers more sources with a per-book cap, and writes a "
                              "blog-ready draft instead of a Q&A-style answer. Slower — runs "
                              "several searches instead of one. Combine with --cloud for best "
                              "quality on the synthesis step.")
    parser.add_argument("--max-total", type=int, default=40,
                         help="Research mode only: cap on total passages sent to the LLM "
                              "regardless of how many different books qualify, spread evenly "
                              "across all of them. Matters more as your library grows — a "
                              "bigger library means more distinct books can plausibly match a "
                              "broad question. Default 40.")
    parser.add_argument("--save", nargs="?", const=True, default=False, metavar="PATH",
                         help="Save the answer to a .txt file. Without a path, saves to "
                              "../library/answers/<timestamp>_<question-slug>.txt. "
                              "Pass a path to save somewhere specific, e.g. --save myfile.txt")
    parser.add_argument("--format", default=None, metavar="PATH_OR_TEXT",
                         help="Custom output structure/style instructions — reusable across "
                              "any question. Pass a path to a text file (recommended for "
                              "anything longer than a sentence) or inline text directly. "
                              "This only shapes HOW the final answer is written; the question "
                              "itself is still what gets searched for, so keep the question "
                              "short and topical (e.g. 'Ruth chapter 3') and put all your "
                              "structure/section/style requirements in the format file instead "
                              "of pasting them into the question — a long question dilutes the "
                              "search itself, which is a different step from formatting.")
    args = parser.parse_args()

    format_instructions = None
    if args.format:
        if os.path.isfile(args.format):
            with open(args.format, "r", encoding="utf-8") as f:
                format_instructions = f.read()
        else:
            format_instructions = args.format

    # --provider rides inside use_cloud as a string; plain --cloud passes
    # True, meaning "use the default provider from .env".
    use_cloud_val = (args.provider or True) if args.cloud else False

    if args.research:
        model = CFG.llm_deep  # research mode is already slow/deliberate; always use the better local model
        result = answer_research(args.question, model=model, use_cloud=use_cloud_val,
                                  max_total=args.max_total, format_instructions=format_instructions)
    else:
        model = CFG.llm_deep if args.deep else CFG.llm_fast
        result = answer(args.question, model=model, use_cloud=use_cloud_val,
                         format_instructions=format_instructions)

    if args.save:
        saved_path = save_answer_to_file(args.question, result, args.save if isinstance(args.save, str) else None)
        print(f"\nSaved answer to: {saved_path}")
