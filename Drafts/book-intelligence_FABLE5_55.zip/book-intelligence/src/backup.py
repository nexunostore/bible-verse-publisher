r"""Back up everything that's expensive to recreate: the Postgres database
(books, chunks, chapters, concepts, summaries, query history — all your
derived intelligence) and the Qdrant vector collection (embeddings).

Usage:
    python backup.py
    python backup.py --include-library   # also back up library/ (covers,
                                          # the moved original EPUB/PDF
                                          # files, generated maps, caches)
    python backup.py --output D:\Backups # write the zip somewhere specific

Restore with restore.py.
"""
import argparse
import json
import os
import shutil
import subprocess
import tempfile
from datetime import datetime

from db import CFG, get_qdrant

POSTGRES_CONTAINER = "book_intel_postgres"
POSTGRES_USER = "bookintel"
POSTGRES_DB = "bookintel"


def backup_postgres(staging_dir: str):
    print("Dumping Postgres database...")
    sql_path = os.path.join(staging_dir, "postgres_dump.sql")
    result = subprocess.run(
        ["docker", "exec", POSTGRES_CONTAINER, "pg_dump",
         "-U", POSTGRES_USER, "-d", POSTGRES_DB, "--clean", "--if-exists"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if result.returncode != 0:
        raise RuntimeError(f"pg_dump failed: {result.stderr}")
    with open(sql_path, "w", encoding="utf-8") as f:
        f.write(result.stdout)
    size_mb = os.path.getsize(sql_path) / (1024 * 1024)
    print(f"  Postgres dump written ({size_mb:.1f} MB)")


def backup_qdrant(staging_dir: str):
    print("Creating Qdrant snapshot...")
    client = get_qdrant()
    snapshot_info = client.create_snapshot(collection_name=CFG.qdrant_collection)
    snapshot_name = snapshot_info.name
    print(f"  Snapshot created: {snapshot_name}, downloading...")

    import requests
    url = f"{CFG.qdrant_url}/collections/{CFG.qdrant_collection}/snapshots/{snapshot_name}"
    local_path = os.path.join(staging_dir, snapshot_name)
    with requests.get(url, stream=True, timeout=600) as resp:
        resp.raise_for_status()
        with open(local_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                f.write(chunk)

    size_mb = os.path.getsize(local_path) / (1024 * 1024)
    print(f"  Qdrant snapshot downloaded ({size_mb:.1f} MB)")

    # Clean up the server-side copy so snapshots don't pile up in the
    # Qdrant volume on every backup run.
    try:
        client.delete_snapshot(collection_name=CFG.qdrant_collection, snapshot_name=snapshot_name)
    except Exception as e:
        print(f"  (note: couldn't clean up server-side snapshot, harmless: {e})")


def backup_library(staging_dir: str):
    print("Copying library/ folder (covers, original files, maps, caches)...")
    library_src = os.path.join(os.path.dirname(__file__), "..", "library")
    library_dst = os.path.join(staging_dir, "library")
    if os.path.isdir(library_src):
        shutil.copytree(library_src, library_dst)
        print("  library/ copied")
    else:
        print("  (no library/ folder found, skipping)")


def backup_config(staging_dir: str):
    print("Copying config files (.env, docker-compose.yml, requirements.txt)...")
    print("  WARNING: .env contains your Anthropic API key if you've set one. "
          "This backup zip now contains a secret — store it securely, don't "
          "upload it anywhere public.")
    project_root = os.path.join(os.path.dirname(__file__), "..")
    config_dst = os.path.join(staging_dir, "config")
    os.makedirs(config_dst, exist_ok=True)
    for fname in (".env", "docker-compose.yml", "requirements.txt"):
        src_path = os.path.join(project_root, fname)
        if os.path.exists(src_path):
            shutil.copy2(src_path, os.path.join(config_dst, fname))
        else:
            print(f"  ({fname} not found, skipping)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="../backups",
                         help="Directory to write the backup zip into")
    parser.add_argument("--include-library", action="store_true",
                         help="Also back up library/ — includes your original EPUB/PDF "
                              "files (the pipeline MOVES originals here on import, so this "
                              "is the only copy that exists once imported), covers, and "
                              "generated maps. Can be large; off by default for speed.")
    parser.add_argument("--include-config", action="store_true",
                         help="Also back up .env, docker-compose.yml, and requirements.txt "
                              "— useful for full-machine disaster recovery, since .env "
                              "(your API key, model settings) isn't tracked anywhere else. "
                              "WARNING: this puts a secret in the backup zip; store it "
                              "securely if you use this flag.")
    args = parser.parse_args()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    staging_dir = tempfile.mkdtemp(prefix="book_intel_backup_")

    try:
        backup_postgres(staging_dir)
        backup_qdrant(staging_dir)
        if args.include_library:
            backup_library(staging_dir)
        if args.include_config:
            backup_config(staging_dir)

        manifest = {
            "created_at": timestamp,
            "includes_library": args.include_library,
            "includes_config": args.include_config,
            "qdrant_collection": CFG.qdrant_collection,
        }
        with open(os.path.join(staging_dir, "manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)

        os.makedirs(args.output, exist_ok=True)
        zip_base = os.path.join(args.output, f"backup_{timestamp}")
        zip_path = shutil.make_archive(zip_base, "zip", staging_dir)

        size_mb = os.path.getsize(zip_path) / (1024 * 1024)
        print(f"\nBackup complete: {os.path.abspath(zip_path)} ({size_mb:.1f} MB)")
        if not args.include_library:
            print("Note: original EPUB/PDF source files were NOT included "
                  "(--include-library to add them).")
        if not args.include_config:
            print("Note: .env/docker-compose.yml were NOT included "
                  "(--include-config to add them — needed for full-machine "
                  "disaster recovery, since .env isn't tracked anywhere else).")
        else:
            print("This zip contains your .env file (API key) — store it securely.")
    finally:
        shutil.rmtree(staging_dir, ignore_errors=True)
