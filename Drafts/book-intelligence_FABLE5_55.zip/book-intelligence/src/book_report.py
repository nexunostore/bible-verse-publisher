"""View everything the pipeline knows about a book.

Usage:
    python book_report.py "atomic habits"
"""
import argparse

from db import get_conn, get_book_report


def print_report(book: dict):
    print(f"\n{'=' * 60}")
    print(f"{book['title']}")
    if book.get("author"):
        print(f"by {book['author']}")
    print("=" * 60)
    if book.get("publisher") or book.get("published_date"):
        print(f"{book.get('publisher') or ''} {book.get('published_date') or ''}".strip())
    if book.get("isbn"):
        print(f"ISBN: {book['isbn']}")
    print(f"Status: {book['status']}")

    print("\n--- Summary ---")
    print(book.get("summary") or "(not yet generated)")

    print("\n--- Major Ideas / Themes ---")
    concepts = book.get("concepts") or []
    if not concepts:
        print("(none extracted)")
    for c in concepts:
        stars = "*" * c["importance"] + "-" * (5 - c["importance"])
        print(f"  [{stars}] {c['name']}")
        if c.get("description"):
            print(f"          {c['description']}")
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("title", help="Full or partial book title to look up")
    args = parser.parse_args()

    conn = get_conn()
    book = get_book_report(conn, args.title)
    conn.close()

    if not book:
        print(f"No book found matching {args.title!r}")
    else:
        print_report(book)
