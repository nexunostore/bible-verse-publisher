"""Parse EPUB files: metadata, cover image, and chapter text.

EPUB is XHTML under the hood, so unlike PDF we get clean text and a real
table of contents for free — no OCR, no font-size heuristics. But two
real-world wrinkles show up often enough to handle explicitly:

1. Multiple TOC entries can point at the SAME physical XHTML file (e.g. a
   Bible packing several short epistles into one file, each referenced by
   its own #anchor). Naively extracting "one chapter per file" silently
   loses everything but the last title mapped to that file.
2. Some books (most notably Bibles) never subdivide a section into
   chapters in the TOC at all — "JOHN" is one TOC entry covering all 21
   chapters. Getting "John chapter 1" as an addressable unit requires
   detecting chapter boundaries from the verse-numbering pattern (1:1,
   1:2, ... 2:1, 2:2...) inside the text itself, not the TOC.
"""
import re

from bs4 import BeautifulSoup, NavigableString
from ebooklib import epub, ITEM_DOCUMENT, ITEM_COVER

# Some EPUBs (usually ones re-packaged by lax conversion tools) declare a
# file in their manifest that isn't actually present in the zip archive —
# most often a stylesheet, sometimes an image. ebooklib hard-crashes the
# entire read on this, even though we don't need CSS/images for text
# extraction at all. Patch it to tolerate a missing archive member by
# returning empty bytes instead of raising, so one broken reference
# (usually irrelevant to us) doesn't sink the whole import.
try:
    _original_read_file = epub.EpubReader.read_file

    def _tolerant_read_file(self, name):
        try:
            return _original_read_file(self, name)
        except KeyError:
            print(f"    (warning: EPUB manifest references missing file {name!r} — skipping it)")
            return b""

    epub.EpubReader.read_file = _tolerant_read_file
except AttributeError:
    # ebooklib's internals differ from what this patch expects — fail safe
    # rather than breaking every import; malformed EPUBs will just crash
    # again as before instead of being tolerated.
    print("(note: could not patch ebooklib for missing-file tolerance — "
          "unaffected for normal EPUBs, but a malformed one may still fail)")


def _clean_isbn(identifiers) -> str | None:
    for ident, _ in identifiers:
        digits = "".join(ch for ch in ident if ch.isdigit() or ch.lower() == "x")
        if len(digits) in (10, 13):
            return digits
    return None


def extract_metadata(book: epub.EpubBook) -> dict:
    def first(namespace, name):
        vals = book.get_metadata(namespace, name)
        return vals[0][0] if vals else None

    identifiers = book.get_metadata("DC", "identifier") or []

    return {
        "title": first("DC", "title"),
        "author": first("DC", "creator"),
        "language": first("DC", "language"),
        "publisher": first("DC", "publisher"),
        "published_date": first("DC", "date"),
        "isbn": _clean_isbn(identifiers),
    }


def extract_cover(book: epub.EpubBook) -> bytes | None:
    for item in book.get_items_of_type(ITEM_COVER):
        return item.get_content()
    for item in book.get_items():
        if "cover" in (item.get_name() or "").lower() and item.media_type.startswith("image/"):
            return item.get_content()
    return None


def _toc_entries_in_order(toc) -> list[tuple]:
    """Flatten book.toc preserving document order.
    Returns [(href_base, fragment_or_None, title), ...]"""
    entries = []

    def walk(nodes):
        for node in nodes:
            target = None
            children = []
            if isinstance(node, tuple):
                target, children = node
            else:
                target = node
            if hasattr(target, "href") and hasattr(target, "title"):
                href_base, _, frag = target.href.partition("#")
                entries.append((href_base, frag or None, target.title))
            if children:
                walk(children)

    walk(toc)
    return entries


def _split_document_by_anchors(soup: BeautifulSoup, frag_title_pairs: list[tuple]) -> list[tuple]:
    """frag_title_pairs: [(fragment_or_None, title), ...] in document order,
    all pointing into the SAME document. Returns [(title, text), ...] by
    slicing the document's text at each anchor's position."""
    anchor_tags = []
    for frag, _title in frag_title_pairs:
        if frag is None:
            anchor_tags.append(None)  # None = start of document
            continue
        tag = soup.find(id=frag) or soup.find("a", attrs={"name": frag})
        anchor_tags.append(tag)

    results = []
    for i, (_frag, title) in enumerate(frag_title_pairs):
        tag = anchor_tags[i]
        next_tag = next((t for t in anchor_tags[i + 1:] if t is not None), None)

        start_point = tag if tag is not None else (soup.body or soup)
        collected = []
        iterator = start_point.descendants if tag is None else start_point.next_elements
        for el in iterator:
            if next_tag is not None and el is next_tag:
                break
            if isinstance(el, NavigableString):
                text = str(el).strip()
                if text:
                    collected.append(text)
        results.append((title, " ".join(collected)))

    return results


def extract_chapters(book: epub.EpubBook) -> list[dict]:
    """Returns spine-ordered chapters: [{index, title, text}, ...]

    Handles multiple TOC entries sharing one physical file by splitting
    that file's content at each entry's anchor position, so e.g. several
    short epistles bundled into one XHTML file each get their own chapter
    instead of collapsing into whichever title happened to be read last.
    """
    toc_entries = _toc_entries_in_order(book.toc)
    href_groups: dict[str, list[tuple]] = {}
    for href, frag, title in toc_entries:
        href_groups.setdefault(href, []).append((frag, title))

    doc_items = {item.get_name(): item for item in book.get_items_of_type(ITEM_DOCUMENT)}

    chapters = []
    idx = 0
    for spine_id, _ in book.spine:
        item = book.get_item_with_id(spine_id)
        if item is None or item.get_name() not in doc_items:
            continue

        soup = BeautifulSoup(item.get_content(), "lxml")
        for tag in soup(["script", "style", "nav"]):
            tag.decompose()

        group = href_groups.get(item.get_name())

        if group and len(group) > 1:
            # Multiple TOC entries share this one file — split it.
            for title, text in _split_document_by_anchors(soup, group):
                if text and len(text) >= 20:
                    chapters.append({"index": idx, "title": title, "text": text})
                    idx += 1
            continue

        # Normal case: one chapter per file.
        text = soup.get_text(separator=" ", strip=True)
        if not text or len(text) < 20:
            continue

        title = group[0][1] if group else None
        if not title:
            h = soup.find(["h1", "h2", "h3"])
            title = h.get_text(strip=True) if h else f"Section {idx + 1}"

        chapters.append({"index": idx, "title": title, "text": text})
        idx += 1

    return chapters


# Matches the start of a Bible-style chapter: a "chapter:verse" reference
# where verse == 1, e.g. "12:1" starting chapter 12. Excludes false
# positives like matching "1" inside "10:15" via negative lookarounds.
_VERSE_CHAPTER_START = re.compile(r"(?<!\d)(\d{1,3}):1(?!\d)")


def subdivide_verse_chapters(chapters: list[dict]) -> list[dict]:
    """For chapters that look like Bible text (many 'N:1' verse-start
    markers in a plausible increasing sequence), split them into
    per-numbered-chapter units, e.g. "JOHN" (23,553 words) ->
    "JOHN 1", "JOHN 2", ... "JOHN 21". Safe no-op for anything that
    doesn't match the pattern strongly (regular prose won't have a long
    run of "N:1" style markers), so this doesn't need to be toggled on
    only for known-Bible books.
    """
    new_chapters = []
    idx = 0
    for ch in chapters:
        text = ch["text"]
        matches = list(_VERSE_CHAPTER_START.finditer(text))
        nums = [int(m.group(1)) for m in matches]

        valid = False
        if len(nums) >= 3 and nums[0] <= 2:
            steps = [nums[i + 1] - nums[i] for i in range(len(nums) - 1)]
            consecutive_ratio = sum(1 for s in steps if s == 1) / len(steps) if steps else 0
            valid = consecutive_ratio >= 0.7

        if not valid:
            new_chapters.append({"index": idx, "title": ch["title"], "text": text})
            idx += 1
            continue

        for i, m in enumerate(matches):
            start = m.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            segment = text[start:end].strip()
            if len(segment) < 10:
                continue
            new_chapters.append({
                "index": idx,
                "title": f"{ch['title']} {nums[i]}",
                "text": segment,
            })
            idx += 1

    return new_chapters


def parse_epub(path: str) -> dict:
    book = epub.read_epub(path)
    chapters = extract_chapters(book)
    chapters = subdivide_verse_chapters(chapters)
    return {
        "metadata": extract_metadata(book),
        "cover": extract_cover(book),
        "chapters": chapters,
    }
