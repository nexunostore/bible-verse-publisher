"""Shared interactive map renderer: a dropdown to focus on one node (a
book, or a concept) and instantly filter down to just its direct
connections, instead of showing the whole graph at once. All filtering
happens client-side in the browser — the graph data is embedded in the
page, so the output stays a single self-contained HTML file, no server
needed. Used by both book_map.py (nodes = books) and knowledge_map.py
(nodes = concepts) so there's one tested implementation instead of two
copies that could drift apart.
"""
import json


def esc(text) -> str:
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def render_interactive_map(nodes_data: list[dict], edges_data: list[dict], output_path: str,
                            page_title: str = "Relationship Map", item_label: str = "book"):
    """nodes_data: [{"id", "label", "tooltip"}, ...]
    edges_data: [{"source", "target", "label", "tooltip"}, ...]
    item_label: what to call one node in the UI text, e.g. "book" or "concept"
    """
    graph_json = json.dumps({"nodes": nodes_data, "edges": edges_data})
    # Guard against a title containing the literal string "</script>", which
    # would otherwise break out of the embedded script tag early.
    graph_json = graph_json.replace("</", "<\\/")

    sorted_options = sorted(nodes_data, key=lambda n: n["label"].lower())
    options_html = "\n".join(
        f'<option value="{esc(n["id"])}">{esc(n["label"])}</option>' for n in sorted_options
    )

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{esc(page_title)}</title>
<style>
body {{ margin:0; background:#111827; font-family:-apple-system,'Segoe UI',sans-serif; color:#e5e7eb; }}
.toolbar {{ padding:16px 24px; background:#1a2436; border-bottom:1px solid #2d3a52; display:flex; align-items:center; gap:12px; }}
.toolbar select {{ background:#111827; color:#e5e7eb; border:1px solid #2d3a52; border-radius:6px; padding:8px 12px; font-size:14px; min-width:280px; }}
.toolbar .hint {{ color:#9aa5b8; font-size:13px; }}
#map-container {{ padding:20px; }}
#map-container svg {{ display:block; margin:0 auto; }}
.empty-msg {{ text-align:center; color:#9aa5b8; padding:60px 20px; font-size:15px; }}
</style>
</head>
<body>
<div class="toolbar">
    <label for="item-select">Focus on one {esc(item_label)}:</label>
    <select id="item-select">
        <option value="">-- Show all --</option>
        {options_html}
    </select>
    <span class="hint" id="status-hint"></span>
</div>
<div id="map-container"></div>

<script>
const GRAPH = {graph_json};
const PALETTE = ["#2ecc71","#f1c40f","#3498db","#9b59b6","#e67e22","#1abc9c",
                  "#e74c3c","#95a5a6","#16a085","#d35400","#8e44ad","#2980b9",
                  "#c0392b","#27ae60","#f39c12","#5dade2"];

function escapeXml(text) {{
    return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}}
function truncate(text, n) {{
    return text.length <= n ? text : text.slice(0, n - 1) + "…";
}}

function buildAllView(nodes, edges) {{
    const sorted = [...nodes].sort((a, b) => a.label.toLowerCase().localeCompare(b.label.toLowerCase()));
    const rowHeight = 42, marginTop = 50, width = 1500;
    const leftX = 30, boxW = 300, rightX = width - 330;
    const height = marginTop * 2 + sorted.length * rowHeight;
    const yOf = {{}};
    sorted.forEach((n, i) => {{ yOf[n.id] = marginTop + i * rowHeight + rowHeight / 2; }});

    let svg = [`<svg viewBox="0 0 ${{width}} ${{height}}" xmlns="http://www.w3.org/2000/svg">`,
               `<rect width="${{width}}" height="${{height}}" fill="#111827"/>`];

    edges.forEach((e, i) => {{
        const color = PALETTE[i % PALETTE.length];
        [[e.source, e.target], [e.target, e.source]].forEach(([a, b]) => {{
            const y1 = yOf[a], y2 = yOf[b];
            const x1 = leftX + boxW, x2 = rightX;
            svg.push(`<line x1="${{x1}}" y1="${{y1}}" x2="${{x2}}" y2="${{y2}}" stroke="${{color}}" stroke-width="2" stroke-opacity="0.8"><title>${{escapeXml(e.tooltip || "")}}</title></line>`);
            if (e.label) {{
                svg.push(`<text x="${{(x1+x2)/2}}" y="${{(y1+y2)/2 - 3}}" fill="${{color}}" font-size="11" text-anchor="middle">${{escapeXml(truncate(e.label, 28))}}</text>`);
            }}
        }});
    }});

    sorted.forEach(n => {{
        const y = yOf[n.id];
        [leftX, rightX].forEach(x => {{
            svg.push(`<rect x="${{x}}" y="${{y - rowHeight/2 + 4}}" width="${{boxW}}" height="${{rowHeight - 8}}" rx="6" fill="#1a2436" stroke="#2d3a52"><title>${{escapeXml(n.tooltip || n.label)}}</title></rect>`);
            svg.push(`<text x="${{x + boxW/2}}" y="${{y+4}}" fill="#e5e7eb" font-size="13" text-anchor="middle">${{escapeXml(truncate(n.label, 34))}}</text>`);
        }});
    }});

    svg.push("</svg>");
    return svg.join("\\n");
}}

function buildFocusedView(nodes, edges, selectedId) {{
    const nodeById = Object.fromEntries(nodes.map(n => [n.id, n]));
    const relevant = edges.filter(e => e.source === selectedId || e.target === selectedId);
    if (relevant.length === 0) return {{ svg: null, neighborCount: 0 }};

    const neighbors = relevant.map(e => {{
        const otherId = e.source === selectedId ? e.target : e.source;
        return {{ id: otherId, label: nodeById[otherId].label, edge: e }};
    }});
    neighbors.sort((a, b) => a.label.toLowerCase().localeCompare(b.label.toLowerCase()));

    const rowHeight = 46, marginTop = 50, width = 1500;
    const leftX = 30, boxW = 320, rightX = width - 350;
    const height = Math.max(marginTop * 2 + neighbors.length * rowHeight, 200);
    const selectedY = height / 2;

    let svg = [`<svg viewBox="0 0 ${{width}} ${{height}}" xmlns="http://www.w3.org/2000/svg">`,
               `<rect width="${{width}}" height="${{height}}" fill="#111827"/>`];

    neighbors.forEach((nb, i) => {{
        const color = PALETTE[i % PALETTE.length];
        const y = marginTop + i * rowHeight + rowHeight / 2;
        const x1 = leftX + boxW, x2 = rightX;
        svg.push(`<line x1="${{x1}}" y1="${{selectedY}}" x2="${{x2}}" y2="${{y}}" stroke="${{color}}" stroke-width="2.5" stroke-opacity="0.85"><title>${{escapeXml(nb.edge.tooltip || "")}}</title></line>`);
        if (nb.edge.label) {{
            svg.push(`<text x="${{(x1+x2)/2}}" y="${{(selectedY+y)/2 - 4}}" fill="${{color}}" font-size="12" text-anchor="middle">${{escapeXml(truncate(nb.edge.label, 30))}}</text>`);
        }}
        svg.push(`<rect x="${{rightX}}" y="${{y - rowHeight/2 + 5}}" width="${{boxW}}" height="${{rowHeight - 10}}" rx="6" fill="#1a2436" stroke="#2d3a52"><title>${{escapeXml(nb.label)}}</title></rect>`);
        svg.push(`<text x="${{rightX + boxW/2}}" y="${{y+4}}" fill="#e5e7eb" font-size="13" text-anchor="middle">${{escapeXml(truncate(nb.label, 36))}}</text>`);
    }});

    svg.push(`<rect x="${{leftX}}" y="${{selectedY - 26}}" width="${{boxW}}" height="52" rx="8" fill="#2d3a52" stroke="#60a5fa" stroke-width="2"/>`);
    svg.push(`<text x="${{leftX + boxW/2}}" y="${{selectedY+5}}" fill="#e5e7eb" font-size="15" font-weight="600" text-anchor="middle">${{escapeXml(truncate(nodeById[selectedId].label, 34))}}</text>`);
    svg.push("</svg>");
    return {{ svg: svg.join("\\n"), neighborCount: neighbors.length }};
}}

function render() {{
    const select = document.getElementById("item-select");
    const container = document.getElementById("map-container");
    const hint = document.getElementById("status-hint");
    const selectedId = select.value;

    if (!selectedId) {{
        container.innerHTML = buildAllView(GRAPH.nodes, GRAPH.edges);
        hint.textContent = `Showing all ${{GRAPH.nodes.length}}`;
        return;
    }}

    const result = buildFocusedView(GRAPH.nodes, GRAPH.edges, selectedId);
    if (result.svg === null) {{
        const label = GRAPH.nodes.find(n => n.id === selectedId).label;
        container.innerHTML = `<div class="empty-msg">"${{escapeXml(label)}}" has no connections at the current settings used when this map was generated. Try regenerating with a looser threshold.</div>`;
        hint.textContent = "";
        return;
    }}
    container.innerHTML = result.svg;
    hint.textContent = `${{result.neighborCount}} connection(s)`;
}}

document.getElementById("item-select").addEventListener("change", render);
render();
</script>
</body></html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Interactive map written to {output_path} — "
          f"open it in a browser and use the dropdown to focus on one {item_label}.")
