"""Chapter-aware chunking.

Deliberately word-count based rather than tokenizer-based: pulling a
tokenizer's vocab file (e.g. tiktoken) typically requires a network call
the first time, which breaks the "fully offline" goal. Word count is a
good enough proxy for chunk sizing here.
"""
import uuid


def chunk_text(text: str, target_words: int, overlap_words: int) -> list[str]:
    words = text.split()
    if len(words) <= target_words:
        return [text]

    chunks = []
    start = 0
    step = max(target_words - overlap_words, 1)
    while start < len(words):
        end = start + target_words
        chunks.append(" ".join(words[start:end]))
        if end >= len(words):
            break
        start += step
    return chunks


def chunk_chapters(chapters: list[dict], target_words: int = 350,
                    overlap_words: int = 50) -> list[dict]:
    """chapters: [{title, text}, ...] -> flat list of chunk dicts ready for
    Postgres insertion + embedding, each carrying its book-relative position
    and chapter title for citation purposes.
    """
    result = []
    chunk_idx = 0
    for ch in chapters:
        pieces = chunk_text(ch["text"], target_words, overlap_words)
        for piece in pieces:
            result.append({
                "id": str(uuid.uuid4()),
                "chapter_title": ch["title"],
                "chunk_index": chunk_idx,
                "text": piece,
                "word_count": len(piece.split()),
            })
            chunk_idx += 1
    return result
