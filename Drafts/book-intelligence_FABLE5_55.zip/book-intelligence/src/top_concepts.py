"""Rank concepts by how many books touch on them — a data-grounded way to
find "most discussed" themes/topics without browsing the knowledge map
dropdown manually. Book count is a real signal from your library, not an
LLM guess.

Usage:
    python top_concepts.py                    # top 20 most-discussed concepts
    python top_concepts.py --limit 10
    python top_concepts.py --search parable    # only concepts matching "parable"
    python top_concepts.py --min-books 2       # only concepts in 2+ books
"""
import argparse

import psycopg2.extras

from db import get_conn


def fetch_concept_rankings(conn, search: str = None, min_books: int = 1):
    query = """
        SELECT c.name,
               COUNT(DISTINCT bc.book_id) AS book_count,
               AVG(bc.importance) AS avg_importance,
               ARRAY_AGG(DISTINCT b.title ORDER BY b.title) AS books
        FROM book_concepts bc
        JOIN concepts c ON c.id = bc.concept_id
        JOIN books b ON b.id = bc.book_id
    """
    conditions, params = [], []
    if search:
        conditions.append("c.name ILIKE %s")
        params.append(f"%{search}%")
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " GROUP BY c.name HAVING COUNT(DISTINCT bc.book_id) >= %s"
    params.append(min_books)
    query += " ORDER BY book_count DESC, avg_importance DESC"

    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(query, params)
        return cur.fetchall()


def print_rankings(rows, limit: int):
    if not rows:
        print("No concepts found matching those filters.")
        return

    shown = rows[:limit]
    print(f"\n{'#':<4}{'Concept':<42}{'Books':<8}{'Avg Importance'}")
    print("-" * 78)
    for i, row in enumerate(shown, 1):
        avg_imp = f"{row['avg_importance']:.1f}/5" if row['avg_importance'] else "—"
        print(f"{i:<4}{row['name'][:40]:<42}{row['book_count']:<8}{avg_imp}")
        sample = ", ".join(row["books"][:3])
        extra = f" (+{len(row['books']) - 3} more)" if len(row["books"]) > 3 else ""
        print(f"    in: {sample}{extra}")
    print(f"\nShowing {len(shown)} of {len(rows)} matching concept(s).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=20, help="How many to show (default 20)")
    parser.add_argument("--search", default=None,
                         help="Only show concepts whose name contains this text, e.g. --search parable")
    parser.add_argument("--min-books", type=int, default=1,
                         help="Only show concepts appearing in at least this many books")
    args = parser.parse_args()

    conn = get_conn()
    rows = fetch_concept_rankings(conn, search=args.search, min_books=args.min_books)
    conn.close()
    print_rankings(rows, args.limit)
