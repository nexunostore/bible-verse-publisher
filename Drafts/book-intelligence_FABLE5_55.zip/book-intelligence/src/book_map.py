"""Book-to-book relationship map.

Nodes are books. An edge is drawn between two books when their
independently-extracted concepts are semantically similar — e.g. the KJV's
"Divinity of Christ" and a commentary's "Christ's Divine Nature" will match
here even though the strings are different, because this compares concept
*embeddings*, not exact text. (knowledge_map.py, by contrast, graphs
concepts as nodes and only merges concepts that are worded identically —
the two scripts answer different questions.)

Usage:
    python book_map.py
    python book_map.py --threshold 0.8     # stricter matching, fewer edges
    python book_map.py --threshold 0.7     # looser matching, more edges
"""
import argparse
import json
import os
from itertools import combinations

import networkx as nx
import numpy as np
from pyvis.network import Network

from db import get_conn
from llm import chat, embed_texts
from map_render import render_interactive_map

CACHE_PATH = os.path.join(os.path.dirname(__file__), "..", "library", "concept_embedding_cache.json")


def load_cache() -> dict:
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_cache(cache: dict):
    os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache, f)


def fetch_book_concepts(conn, publisher_filter: str = None, title_filter: str = None) -> dict:
    query = """SELECT b.id, b.title, b.author, b.publisher, c.name, bc.importance
               FROM book_concepts bc
               JOIN books b ON b.id = bc.book_id
               JOIN concepts c ON c.id = bc.concept_id"""
    conditions, params = [], []
    if publisher_filter:
        conditions.append("b.publisher ILIKE %s")
        params.append(f"%{publisher_filter}%")
    if title_filter:
        conditions.append("b.title ILIKE %s")
        params.append(f"%{title_filter}%")
    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    with conn.cursor() as cur:
        cur.execute(query, params)
        rows = cur.fetchall()

    books = {}
    for book_id, title, author, publisher, name, importance in rows:
        books.setdefault(book_id, {"title": title, "author": author, "publisher": publisher, "concepts": []})
        books[book_id]["concepts"].append((name, importance or 3))
    return books


def get_embeddings(concept_names: list[str], cache: dict) -> dict:
    # Only embed names we haven't seen before — the cache persists across
    # runs in library/concept_embedding_cache.json, so re-running this on a
    # growing library only pays the embedding cost for genuinely new concepts.
    to_embed = [n for n in concept_names if n not in cache]
    if to_embed:
        print(f"Embedding {len(to_embed)} new concept name(s) (cached ones skipped)...")
        vectors = embed_texts(to_embed, show_progress=True)
        for name, vec in zip(to_embed, vectors):
            cache[name] = vec
    return {n: np.array(cache[n]) for n in concept_names}


def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / denom) if denom else 0.0


def build_book_graph(books: dict, threshold: float = 0.78) -> nx.Graph:
    all_names = sorted({name for b in books.values() for name, _ in b["concepts"]})
    cache = load_cache()
    embeddings = get_embeddings(all_names, cache)
    save_cache(cache)

    graph = nx.Graph()
    for book_id, info in books.items():
        graph.add_node(
            book_id,
            label=info["title"],
            size=15 + len(info["concepts"]),
            title=f"{info['title']}\nby {info['author'] or 'Unknown'}\n{len(info['concepts'])} concepts",
        )

    for a_id, b_id in combinations(books.keys(), 2):
        matches = []
        for name_a, _ in books[a_id]["concepts"]:
            best = None
            for name_b, _ in books[b_id]["concepts"]:
                sim = cosine_sim(embeddings[name_a], embeddings[name_b])
                if sim >= threshold and (best is None or sim > best[2]):
                    best = (name_a, name_b, sim)
            if best and best not in matches:
                matches.append(best)
        if matches:
            tooltip = "\n".join(f"{a} ~ {b} ({s:.2f})" for a, b, s in matches)
            graph.add_edge(a_id, b_id, value=len(matches), matches=matches,
                            title=f"Shared themes:\n{tooltip}")

    return graph


def prune_to_top_edges(graph: nx.Graph, max_edges_per_node: int = 4) -> nx.Graph:
    """Keeps an edge only if it's among the strongest connections for at
    least one of its two endpoints. Without this, a library of closely
    related books (an entire Bible split into 66 books is the extreme
    case — every book IS genuinely thematically related to every other)
    produces a graph so dense it's unreadable. A higher similarity
    threshold doesn't fix this — it's not that the connections are false,
    it's that showing every true connection at once is too much. This
    keeps only each book's most distinctive relationships instead.
    """
    keep_edges = set()
    for node in graph.nodes:
        incident = sorted(
            graph.edges(node, data=True),
            key=lambda e: e[2].get("value", 0),
            reverse=True,
        )
        for u, v, _ in incident[:max_edges_per_node]:
            keep_edges.add(frozenset((u, v)))

    pruned = nx.Graph()
    pruned.add_nodes_from(graph.nodes(data=True))
    for u, v, data in graph.edges(data=True):
        if frozenset((u, v)) in keep_edges:
            pruned.add_edge(u, v, **data)
    return pruned


def label_relationship(title_a: str, title_b: str, matches: list, model: str = None, use_cloud: bool = False) -> str:
    """Turns a raw concept-similarity match into a short, human-readable
    relationship label shown directly on the edge — 'shares theme: grace',
    'contrasts on judgment' — instead of just an unlabeled line you have
    to hover over to understand."""
    match_lines = "\n".join(f"- {a} <-> {b}" for a, b, _s in matches[:5])
    prompt = (
        f'Two books, "{title_a}" and "{title_b}", share these overlapping themes:\n'
        f"{match_lines}\n\n"
        "In 2-5 words, describe how these books relate — like a knowledge-graph "
        'edge label, e.g. "shares theme: grace", "contrasts on judgment", '
        '"expands on covenant". Respond with ONLY the short label, nothing else — '
        "no quotes, no punctuation, no explanation."
    )
    try:
        label = chat(prompt, model=model, use_cloud=use_cloud).strip().strip('"').strip("'")
        return label[:40] if label else "related"
    except Exception:
        return "related"


def label_all_edges(graph: nx.Graph, model: str = None, use_cloud: bool = False):
    total = graph.number_of_edges()
    for i, (u, v, data) in enumerate(graph.edges(data=True), 1):
        title_a, title_b = graph.nodes[u]["label"], graph.nodes[v]["label"]
        label = label_relationship(title_a, title_b, data.get("matches", []), model=model, use_cloud=use_cloud)
        data["label"] = label
        print(f"  [{i}/{total}] {title_a} — {label} — {title_b}")


def default_output_path(args) -> str:
    """Avoids a filtered map silently overwriting the full-library map —
    both used to default to the same filename."""
    parts = []
    if args.publisher:
        parts.append(args.publisher.lower().replace(" ", "_"))
    if args.title:
        parts.append(args.title.lower().replace(" ", "_"))
    if not parts:
        return "../library/book_map.html"
    return f"../library/book_map_{'_'.join(parts)}.html"


def render_columns(graph: nx.Graph, output_path: str):
    """Interactive two-column map — see map_render.py for how the
    dropdown-to-focus-on-one-book filtering actually works."""
    nodes_data = [
        {"id": str(n), "label": graph.nodes[n]["label"], "tooltip": graph.nodes[n].get("title", "")}
        for n in graph.nodes
    ]
    edges_data = [
        {"source": str(u), "target": str(v), "label": data.get("label", ""),
         "tooltip": data.get("title", "related").replace("\n", " | ")}
        for u, v, data in graph.edges(data=True)
    ]
    render_interactive_map(nodes_data, edges_data, output_path,
                           page_title="Book Relationship Map", item_label="book")


def render(graph: nx.Graph, output_path: str):
    net = Network(height="900px", width="100%", bgcolor="#111827",
                  font_color="#e5e7eb", cdn_resources="local")
    net.from_nx(graph)
    net.repulsion(node_distance=220, spring_length=250)
    net.write_html(output_path, notebook=False)
    print(f"Book relationship map written to {output_path} — open it in a browser.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=None,
                         help="Output HTML path. Defaults to library/book_map.html, or "
                              "library/book_map_<filter>.html if --publisher/--title is set, "
                              "so a filtered map doesn't overwrite your full-library one.")
    parser.add_argument("--threshold", type=float, default=0.78,
                         help="Cosine similarity cutoff for 'same theme' (0-1, higher = stricter)")
    parser.add_argument("--max-edges", type=int, default=4,
                         help="Keep only each book's N strongest connections — the main lever "
                              "for readability. Lower this (e.g. 2-3) if the map still looks "
                              "like a hairball; raise it (or use 0 to disable) if it looks too sparse.")
    parser.add_argument("--publisher", default=None,
                         help="Only include books whose publisher/version field matches this "
                              "(e.g. --publisher KJV). import_bible_json.py stores your --version "
                              "label there, so this is how you get a map of just one translation.")
    parser.add_argument("--title", default=None,
                         help="Only include books whose title matches this (partial match)")
    parser.add_argument("--label-edges", action="store_true",
                         help="Use the LLM to label each edge with what the relationship "
                              "actually is (e.g. 'shares theme: grace'), shown directly on the "
                              "edge instead of only in a hover tooltip. Adds one LLM call per "
                              "edge shown, so this takes noticeably longer.")
    parser.add_argument("--cloud", action="store_true",
                         help="Use Anthropic's API for edge labeling instead of the local LLM "
                              "(only relevant with --label-edges; embeddings/similarity always "
                              "stay local either way)")
    parser.add_argument("--model", default=None,
                         help="Local model to use for edge labeling (defaults to LLM_MODEL_FAST)")
    parser.add_argument("--style", choices=["columns", "network"], default="columns",
                         help="'columns' (default): fixed two-column layout, each book gets one "
                              "row, easy to trace by eye. 'network': the original physics-"
                              "simulated graph — nodes move/cluster based on connections, which "
                              "can look nicer for a small library but turns into an unreadable "
                              "'hairball' once you have many closely related books.")
    args = parser.parse_args()

    conn = get_conn()
    books = fetch_book_concepts(conn, publisher_filter=args.publisher, title_filter=args.title)
    conn.close()

    if not books:
        print("No books with concepts found matching those filters — run the import "
              "pipeline first, or check your --publisher/--title spelling.")
    else:
        graph = build_book_graph(books, threshold=args.threshold)
        full_edge_count = graph.number_of_edges()

        if args.max_edges > 0:
            graph = prune_to_top_edges(graph, max_edges_per_node=args.max_edges)
            print(f"Pruned {full_edge_count} -> {graph.number_of_edges()} edges "
                  f"(keeping each book's top {args.max_edges} connection(s))")

        if args.label_edges and graph.number_of_edges() > 0:
            print(f"Labeling {graph.number_of_edges()} edge(s) with relationship "
                  f"descriptions{' via cloud' if args.cloud else ''}...")
            label_all_edges(graph, model=args.model, use_cloud=args.cloud)

        output_path = args.output or default_output_path(args)
        if args.style == "columns":
            render_columns(graph, output_path)
        else:
            render(graph, output_path)
        isolated = [n for n in graph.nodes if graph.degree(n) == 0]
        print(f"{graph.number_of_nodes()} books, {graph.number_of_edges()} connections shown "
              f"({len(isolated)} book(s) with no matches above threshold {args.threshold}).")
        if isolated:
            print("If books you expected to connect show up isolated, try a lower --threshold.")
        print("If the map still looks too dense, try: python book_map.py --max-edges 2")
        print("If it looks too sparse, try: python book_map.py --max-edges 8")
