"""Import a structured JSON Bible dump — the format where each chapter is
its own JSON file:

    <books_dir>/<book-slug>/chapters/<N>.json

Each chapter file holds verse objects, e.g. [{"verse": 1, "text": "..."}]
or wrapped like {"verses": [{"verse": 1, "text": "..."}]} — this handles
both, since the exact shape can vary between JSON Bible dumps.

Every biblical book (Genesis, Psalms, Matthew, ...) is imported as its
own separate book in your library, with EXACT chapter/verse boundaries —
no heuristics needed here, unlike an EPUB Bible where chapter breaks have
to be guessed from formatting.

Usage:
    python import_bible_json.py "D:\\path\\to\\bible-api\\versions\\asv\\books" --version "ASV"
"""
import argparse
import hashlib
import json
import os
import re

from pipeline import import_book_from_parsed

# Canonical 66-book list: slug -> display title. Slugs match the common
# bible-api/wldeh-style convention (e.g. "1-chronicles", "song-of-solomon").
# If your folder names differ, add/adjust entries here — anything not
# found falls back to a best-effort title derived from the folder name.
BOOKS = [
    ("genesis", "Genesis"), ("exodus", "Exodus"), ("leviticus", "Leviticus"),
    ("numbers", "Numbers"), ("deuteronomy", "Deuteronomy"), ("joshua", "Joshua"),
    ("judges", "Judges"), ("ruth", "Ruth"), ("1-samuel", "1 Samuel"),
    ("2-samuel", "2 Samuel"), ("1-kings", "1 Kings"), ("2-kings", "2 Kings"),
    ("1-chronicles", "1 Chronicles"), ("2-chronicles", "2 Chronicles"),
    ("ezra", "Ezra"), ("nehemiah", "Nehemiah"), ("esther", "Esther"),
    ("job", "Job"), ("psalms", "Psalms"), ("proverbs", "Proverbs"),
    ("ecclesiastes", "Ecclesiastes"), ("song-of-solomon", "Song of Solomon"),
    ("isaiah", "Isaiah"), ("jeremiah", "Jeremiah"), ("lamentations", "Lamentations"),
    ("ezekiel", "Ezekiel"), ("daniel", "Daniel"), ("hosea", "Hosea"),
    ("joel", "Joel"), ("amos", "Amos"), ("obadiah", "Obadiah"), ("jonah", "Jonah"),
    ("micah", "Micah"), ("nahum", "Nahum"), ("habakkuk", "Habakkuk"),
    ("zephaniah", "Zephaniah"), ("haggai", "Haggai"), ("zechariah", "Zechariah"),
    ("malachi", "Malachi"),
    ("matthew", "Matthew"), ("mark", "Mark"), ("luke", "Luke"), ("john", "John"),
    ("acts", "Acts"), ("romans", "Romans"), ("1-corinthians", "1 Corinthians"),
    ("2-corinthians", "2 Corinthians"), ("galatians", "Galatians"),
    ("ephesians", "Ephesians"), ("philippians", "Philippians"),
    ("colossians", "Colossians"), ("1-thessalonians", "1 Thessalonians"),
    ("2-thessalonians", "2 Thessalonians"), ("1-timothy", "1 Timothy"),
    ("2-timothy", "2 Timothy"), ("titus", "Titus"), ("philemon", "Philemon"),
    ("hebrews", "Hebrews"), ("james", "James"), ("1-peter", "1 Peter"),
    ("2-peter", "2 Peter"), ("1-john", "1 John"), ("2-john", "2 John"),
    ("3-john", "3 John"), ("jude", "Jude"), ("revelation", "Revelation"),
]
SLUG_TO_TITLE = {slug: title for slug, title in BOOKS}


def _slug_to_title_fallback(slug: str) -> str:
    words = slug.replace("_", "-").split("-")
    return " ".join(w.upper() if w.isdigit() else w.capitalize() for w in words)


def _strip_tags(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text)


def load_chapter(path: str) -> dict:
    """Handles both a bare verse array and a wrapped object — the exact
    shape varies between JSON Bible dumps, so this checks a few common
    wrapper keys before giving up. Also pulls out "book"/"chapter" fields
    when the file provides them directly (as bible-api dumps typically
    do) — that's more reliable than inferring from folder/file names."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    embedded_book, embedded_chapter, verses = None, None, None

    if isinstance(data, list):
        verses = data
    elif isinstance(data, dict):
        embedded_book = data.get("book")
        embedded_chapter = data.get("chapter")
        for key in ("verses", "data", "content", "text"):
            if isinstance(data.get(key), list):
                verses = data[key]
                break
        if verses is None:
            for value in data.values():
                if isinstance(value, list):
                    verses = value
                    break
        if verses is None:
            raise ValueError(f"Could not find a verse array in {path}")
    else:
        raise ValueError(f"Unexpected JSON structure in {path}: {type(data)}")

    chapter_num = None
    if embedded_chapter is not None:
        try:
            chapter_num = int(embedded_chapter)
        except (TypeError, ValueError):
            chapter_num = None

    verses_sorted = sorted(verses, key=lambda v: v.get("verse", 0))
    text = " ".join(
        f"{v.get('verse', '?')} {_strip_tags(str(v.get('text', ''))).strip()}"
        for v in verses_sorted
    )
    return {"book": embedded_book, "chapter": chapter_num, "text": text}


def import_book_folder(book_dir: str, version_label: str):
    slug = os.path.basename(book_dir.rstrip("/\\")).lower()

    chapters_dir = os.path.join(book_dir, "chapters")
    if not os.path.isdir(chapters_dir):
        print(f"  Skipping {slug!r} — no chapters/ folder found")
        return

    chapter_files = [f for f in os.listdir(chapters_dir) if f.lower().endswith(".json")]
    chapter_files.sort(key=lambda f: int(re.sub(r"\D", "", f) or 0))  # numeric, not alphabetic

    if not chapter_files:
        print(f"  Skipping {slug!r} — no chapter files found")
        return

    hasher = hashlib.sha256()
    chapters = []
    resolved_title = None

    for idx, fname in enumerate(chapter_files):
        fpath = os.path.join(chapters_dir, fname)
        with open(fpath, "rb") as f:
            raw = f.read()
        hasher.update(raw)

        try:
            result = load_chapter(fpath)
        except Exception as e:
            print(f"    (warning: failed to parse {fname}: {e} — skipping this chapter)")
            continue
        if not result["text"].strip():
            continue

        if resolved_title is None and result.get("book"):
            embedded = result["book"].lower()
            resolved_title = SLUG_TO_TITLE.get(embedded, _slug_to_title_fallback(embedded))

        title_so_far = resolved_title or SLUG_TO_TITLE.get(slug) or _slug_to_title_fallback(slug)
        chapter_num = result["chapter"] if result["chapter"] is not None else int(re.sub(r"\D", "", fname) or (idx + 1))
        chapters.append({"index": idx, "title": f"{title_so_far} {chapter_num}", "text": result["text"]})

    if not chapters:
        print(f"  Skipping {slug!r} — no chapters parsed successfully")
        return

    title = resolved_title or SLUG_TO_TITLE.get(slug) or _slug_to_title_fallback(slug)
    if not resolved_title and slug not in SLUG_TO_TITLE:
        print(f"  (note: {slug!r} not in known book list — guessing title {title!r})")

    print(f"\n[+] Processing {title} ({len(chapters)} chapters)")

    if not chapters:
        print(f"  Skipping {title!r} — no chapters parsed successfully")
        return

    sha256 = hasher.hexdigest()
    meta = {
        "title": title,
        "author": None,
        "language": "en",
        "publisher": version_label,
        "published_date": None,
        "isbn": None,
    }
    parsed = {"metadata": meta, "chapters": chapters}
    import_book_from_parsed(parsed, sha256, source_path=book_dir, source_format="bible-json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("books_dir", help="Path to the 'books' folder (one subfolder per Bible book)")
    parser.add_argument("--version", default="Bible", help="Translation label, e.g. 'ASV' (stored as publisher)")
    args = parser.parse_args()

    book_dirs = sorted(
        os.path.join(args.books_dir, d) for d in os.listdir(args.books_dir)
        if os.path.isdir(os.path.join(args.books_dir, d))
    )
    print(f"Found {len(book_dirs)} book folder(s) in {args.books_dir}")
    for bd in book_dirs:
        import_book_folder(bd, args.version)
