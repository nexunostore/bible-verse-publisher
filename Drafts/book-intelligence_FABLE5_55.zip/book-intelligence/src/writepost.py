"""Generate a full, structured blog post for your Bible study — a
dedicated tool for that one workflow, separate from query.py. It reuses
the same tested search/synthesis functions (so there's one source of
truth for how retrieval works), but has its own simple, stable interface
that won't change just because query.py grows new experimental flags.

Usage:
    python writepost.py "king david"
    python writepost.py "king david" --format person_profile
    python writepost.py "ruth chapter 3" --format bible_chapter_study
    python writepost.py "what does my library say about grace"
    python writepost.py "king david" --local        # skip cloud, use local model
    python writepost.py "king david" --no-prompt     # don't ask which format, just pick one

Always checks library/lookups/ first for a named match (a specific
chapter or a person's story); falls back to a broad research search if
nothing matches. Always uses a format from library/formats/ — auto-
suggested based on the match type, or pick one yourself. Always saves
the result to a file.
"""
import argparse
import os

from db import CFG, get_conn
from query import (_core_title, answer_chapter, answer_named_multi,
                    answer_research, find_book_by_fragment,
                    find_chapter_reference, find_matching_book,
                    find_named_reference, load_named_lookups,
                    resolve_related, save_answer_to_file)

FORMATS_DIR = os.path.join(os.path.dirname(__file__), "..", "library", "formats")


def list_formats() -> list[str]:
    if not os.path.isdir(FORMATS_DIR):
        return []
    return sorted(f[:-4] for f in os.listdir(FORMATS_DIR) if f.endswith(".txt"))


def load_format(name: str) -> str | None:
    path = os.path.join(FORMATS_DIR, f"{name}.txt")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def suggest_format(named_match: dict | None) -> str | None:
    """Picks a sensible default format based on what kind of thing
    matched — a single chapter suggests the chapter-study format, a
    person spanning several chapters suggests the person-profile
    format. Only suggests a format that actually exists."""
    available = list_formats()
    if named_match is None:
        return None
    # A person match is recognizable by its source file (people.json) or by
    # spanning multiple chapters. Location count alone stopped being a
    # reliable signal once people.json entries became single-chapter with
    # their breadth carried in 'related' links instead.
    is_person = (named_match.get("source_file") == "people.json"
                 or len(named_match["locations"]) > 1)
    candidate = "person_profile" if is_person else "bible_chapter_study"
    return candidate if candidate in available else None


def choose_format(format_name: str = None, named_match: dict = None, prompt: bool = True) -> str | None:
    if format_name:
        instructions = load_format(format_name)
        if instructions is None:
            print(f"(format {format_name!r} not found in library/formats/ — using default structure)")
        return instructions

    suggested = suggest_format(named_match)
    if not prompt:
        return load_format(suggested) if suggested else None

    formats = list_formats()
    if not formats:
        return None

    print("\nAvailable formats:")
    for i, f in enumerate(formats, 1):
        marker = "  <- suggested" if f == suggested else ""
        print(f"  {i}. {f}{marker}")
    print("  0. No format (default structure)")

    default_idx = str(formats.index(suggested) + 1) if suggested in formats else "0"
    choice = input(f"Pick a format [{default_idx}]: ").strip() or default_idx

    if choice == "0":
        return None
    try:
        return load_format(formats[int(choice) - 1])
    except (ValueError, IndexError):
        print("Invalid choice — using default structure.")
        return None


def write_post(topic: str, format_name: str = None, use_cloud: bool = True,
               model: str = None, prompt_for_format: bool = True) -> str:
    conn = get_conn()
    used_model = model or CFG.llm_deep  # always the better model for a real post

    lookups, id_index = load_named_lookups()
    named_match = find_named_reference(topic, lookups)
    format_instructions = choose_format(format_name, named_match, prompt=prompt_for_format)

    if use_cloud:
        provider = use_cloud if isinstance(use_cloud, str) else CFG.cloud_provider
        cloud_model_name = CFG.openai_model if provider == "openai" else CFG.cloud_model
        print(f"\n(synthesizing with cloud [{provider}]: {cloud_model_name})")
    else:
        print(f"\n(synthesizing with local: {used_model})")

    if named_match:
        locations = named_match["locations"]
        # Same routing rule as query.py's answer(): single-location entries
        # WITH 'related' cross-links must go through answer_named_multi,
        # or the links never fire (people.json is single-chapter by design).
        if len(locations) == 1 and not named_match.get("related"):
            loc = locations[0]
            candidates = find_book_by_fragment(conn, loc["book"])
            if candidates:
                print(f"\nFound: {named_match['alias']!r} -> {loc['book']} chapter {loc['chapter']}\n")
                result = answer_chapter(conn, candidates[0], str(loc["chapter"]), topic, used_model,
                                         use_cloud=use_cloud, format_instructions=format_instructions)
                conn.close()
                return result
        else:
            n_related = len(named_match.get("related", []))
            print(f"\nFound: {named_match['alias']!r} -> {len(locations)} chapter(s)"
                  + (f" + {n_related} cross-linked entries" if n_related else "") + "\n")
            result = answer_named_multi(conn, named_match, topic, used_model,
                                         use_cloud=use_cloud, format_instructions=format_instructions,
                                         id_index=id_index)
            conn.close()
            return result

    print(f"\nNo specific lookup match for {topic!r} — checking for a direct "
          f"book/chapter reference before falling back to broad search.\n")

    # Direct book+chapter detection (same routing query.py's answer() uses).
    # Without this, a topic like "John chapter 3" falls through to semantic
    # search — which can't reliably tell "John 3" (the Gospel) apart from
    # "3 John" (the epistle), and happily returns the wrong book.
    matched_book = find_matching_book(conn, topic)
    if matched_book:
        chapter_ref = find_chapter_reference(topic, _core_title(matched_book["title"]))
        if chapter_ref:
            print(f"Found: {matched_book['title']!r} chapter {chapter_ref} (direct chapter match)\n")
            result = answer_chapter(conn, matched_book, chapter_ref, topic, used_model,
                                     use_cloud=use_cloud, format_instructions=format_instructions)
            conn.close()
            return result

    print(f"No direct chapter reference either — doing a broader research "
          f"search across your library instead.\n")
    conn.close()
    return answer_research(topic, model=used_model, use_cloud=use_cloud,
                            format_instructions=format_instructions)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("topic", help="What to write about — a person, a chapter, or a broad topic")
    parser.add_argument("--format", default=None,
                         help="Format name from library/formats/ (without .txt). "
                              "If not given, you'll be asked interactively unless --no-prompt.")
    parser.add_argument("--local", action="store_true",
                         help="Use the local model instead of the cloud (free, but lower quality)")
    parser.add_argument("--provider", choices=["anthropic", "openai"], default=None,
                         help="Which cloud provider to use (overrides CLOUD_PROVIDER from .env). "
                              "Ignored with --local.")
    parser.add_argument("--no-prompt", action="store_true",
                         help="Don't ask which format to use — just pick the best guess automatically")
    args = parser.parse_args()

    try:
        post = write_post(
            args.topic,
            format_name=args.format,
            use_cloud=False if args.local else (args.provider or True),
            prompt_for_format=not args.no_prompt and not args.format,
        )
    except RuntimeError as e:
        # Most likely: --local wasn't passed and ANTHROPIC_API_KEY isn't set
        print(f"\nError: {e}")
        print("If you don't have a cloud API key set up, try again with --local")
        raise SystemExit(1)

    # Local runs stream the post live as it generates, so reprinting it
    # here would show the whole thing twice; cloud runs print nothing
    # during generation, so they need this final print.
    if not args.local:
        print("\n" + "=" * 70)
        print(post)

    saved_path = save_answer_to_file(args.topic, post)
    print(f"\nSaved to: {saved_path}")
