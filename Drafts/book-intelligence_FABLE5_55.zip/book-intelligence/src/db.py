"""Config loading + Postgres/Qdrant connection helpers."""
import os
import uuid
from dataclasses import dataclass

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams

load_dotenv()


@dataclass
class Config:
    incoming_dir: str = os.getenv("INCOMING_DIR", "./incoming")
    library_dir: str = os.getenv("LIBRARY_DIR", "./library")
    duplicates_dir: str = os.getenv("DUPLICATES_DIR", "./duplicates")
    covers_dir: str = os.getenv("COVERS_DIR", "./library/covers")

    postgres_dsn: str = os.getenv(
        "POSTGRES_DSN", "postgresql://bookintel:bookintel@localhost:5432/bookintel"
    )

    qdrant_url: str = os.getenv("QDRANT_URL", "http://localhost:6333")
    qdrant_collection: str = os.getenv("QDRANT_COLLECTION", "book_chunks")

    ollama_url: str = os.getenv("OLLAMA_URL", "http://localhost:11434")
    # How long Ollama keeps a model loaded in memory after use. Default
    # Ollama behavior unloads after 5 minutes idle — during a bulk import
    # that alternates between the embedding model and the summary/concept
    # model book after book, this causes repeated multi-GB reloads. 30m
    # keeps both resident across a whole import run.
    ollama_keep_alive: str = os.getenv("OLLAMA_KEEP_ALIVE", "30m")
    embed_model: str = os.getenv("EMBED_MODEL", "nomic-embed-text")
    embed_dim: int = int(os.getenv("EMBED_DIM", "768"))

    llm_fast: str = os.getenv("LLM_MODEL_FAST", "qwen3:8b")
    llm_deep: str = os.getenv("LLM_MODEL_DEEP", "qwen3:14b")

    # Optional cloud fallback for higher-quality synthesis — opt-in via
    # --cloud, sends only the retrieved excerpts + question to Anthropic's
    # API for that one call. Everything else (embeddings, search, rerank)
    # stays local regardless.
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    cloud_model: str = os.getenv("CLOUD_MODEL", "claude-sonnet-5")
    # Which cloud provider --cloud uses by default: "anthropic" or "openai".
    # Either can also be chosen per-query (CLI --provider flag, web dropdown).
    cloud_provider: str = os.getenv("CLOUD_PROVIDER", "anthropic").lower()
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    # Check platform.openai.com for current model names if this errors.
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5.1")
    # Local: -1 means "generate until natural stop or context limit" — Ollama's
    # own per-model defaults are sometimes surprisingly low (128 tokens on some
    # models), which silently truncates long answers mid-sentence.
    local_num_predict: int = int(os.getenv("LOCAL_NUM_PREDICT", "-1"))
    # Context window for local models. Ollama's default is small (often
    # 4096 tokens) and it SILENTLY truncates anything beyond it — synthesis
    # prompts (chapter text + excerpts from other books + format
    # instructions) easily exceed that, meaning the local model literally
    # never saw most of the retrieved material. A major hidden cause of
    # local answers being much thinner than cloud ones. 16384 fits
    # qwen3:8b/14b on a 12GB GPU; drop to 8192 if generation gets slow.
    local_num_ctx: int = int(os.getenv("LOCAL_NUM_CTX", "16384"))
    # Cloud: Claude Sonnet 5 supports up to 128k output tokens; this was
    # previously hardcoded to 2000 in the API call, which is what was cutting
    # off longer answers (chapter summaries + study notes, research drafts).
    cloud_max_tokens: int = int(os.getenv("CLOUD_MAX_TOKENS", "8192"))

    chunk_target_words: int = int(os.getenv("CHUNK_TARGET_WORDS", "350"))
    chunk_overlap_words: int = int(os.getenv("CHUNK_OVERLAP_WORDS", "50"))

    reranker_model: str = os.getenv("RERANKER_MODEL", "BAAI/bge-reranker-v2-m3")


CFG = Config()


def get_conn():
    return psycopg2.connect(CFG.postgres_dsn)


def get_qdrant() -> QdrantClient:
    # Longer timeout + batching (see upsert_points_batched) — a single
    # request with thousands of points is prone to connection resets,
    # especially over Docker Desktop's Windows networking.
    return QdrantClient(url=CFG.qdrant_url, timeout=60)


def upsert_points_batched(qdrant: QdrantClient, collection: str, points: list,
                           batch_size: int = 200, max_retries: int = 3):
    """Upload points in small batches with retry-on-failure, instead of one
    giant request. A big book (thousands of chunks) sent as a single
    request is exactly what triggers WinError 10053 / connection resets."""
    import time as _time

    for i in range(0, len(points), batch_size):
        batch = points[i:i + batch_size]
        for attempt in range(1, max_retries + 1):
            try:
                qdrant.upsert(collection_name=collection, points=batch)
                break
            except Exception as e:
                if attempt == max_retries:
                    raise
                wait = 2 ** attempt
                print(f"    Qdrant batch {i // batch_size + 1} failed "
                      f"(attempt {attempt}/{max_retries}): {e}. Retrying in {wait}s...")
                _time.sleep(wait)


def ensure_qdrant_collection(client: QdrantClient):
    existing = [c.name for c in client.get_collections().collections]
    if CFG.qdrant_collection not in existing:
        client.create_collection(
            collection_name=CFG.qdrant_collection,
            vectors_config=VectorParams(size=CFG.embed_dim, distance=Distance.COSINE),
        )


# --- Book / job helpers -----------------------------------------------------

def book_exists_by_hash(conn, sha256: str):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT id, title FROM books WHERE sha256 = %s", (sha256,))
        return cur.fetchone()


def create_job(conn, file_path: str, sha256: str) -> str:
    job_id = str(uuid.uuid4())
    with conn.cursor() as cur:
        cur.execute(
            """INSERT INTO import_jobs (job_id, file_path, sha256, status, stage)
               VALUES (%s, %s, %s, 'running', 'hashing')""",
            (job_id, file_path, sha256),
        )
    conn.commit()
    return job_id


def update_job(conn, job_id: str, stage: str = None, status: str = None,
                error_message: str = None, book_id: str = None):
    fields, values = ["updated_at = now()"], []
    if stage:
        fields.append("stage = %s")
        values.append(stage)
    if status:
        fields.append("status = %s")
        values.append(status)
    if error_message:
        fields.append("error_message = %s")
        values.append(error_message)
    if book_id:
        fields.append("book_id = %s")
        values.append(book_id)
    values.append(job_id)
    with conn.cursor() as cur:
        cur.execute(f"UPDATE import_jobs SET {', '.join(fields)} WHERE job_id = %s", values)
    conn.commit()


def insert_book(conn, sha256: str, meta: dict, source_path: str, cover_path: str = None,
                 source_format: str = "epub") -> str:
    book_id = str(uuid.uuid4())
    with conn.cursor() as cur:
        cur.execute(
            """INSERT INTO books (id, sha256, title, author, isbn, language,
                                   publisher, published_date, source_path,
                                   source_format, cover_path, status)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'processing')""",
            (book_id, sha256, meta.get("title"), meta.get("author"),
             meta.get("isbn"), meta.get("language"), meta.get("publisher"),
             meta.get("published_date"), source_path, source_format, cover_path),
        )
    conn.commit()
    return book_id


def update_book(conn, book_id: str, **fields):
    if not fields:
        return
    fields["updated_at"] = "now()"
    set_clause = ", ".join(
        f"{k} = now()" if v == "now()" else f"{k} = %s" for k, v in fields.items()
    )
    values = [v for v in fields.values() if v != "now()"]
    with conn.cursor() as cur:
        cur.execute(f"UPDATE books SET {set_clause} WHERE id = %s", values + [book_id])
    conn.commit()


def _normalize_name(name: str) -> str:
    return " ".join(name.strip().lower().split())


def get_or_create_author(conn, name: str) -> str:
    norm = _normalize_name(name)
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT id FROM authors WHERE normalized_name = %s", (norm,))
        row = cur.fetchone()
        if row:
            return row["id"]
        author_id = str(uuid.uuid4())
        cur.execute(
            "INSERT INTO authors (id, name, normalized_name) VALUES (%s, %s, %s)",
            (author_id, name.strip(), norm),
        )
    conn.commit()
    return author_id


def save_book_authors(conn, book_id: str, author_names: list[str]):
    """author_names: e.g. ['Jane Doe', 'John Smith'] — splits on common
    separators so a raw EPUB creator string like 'Jane Doe & John Smith'
    or 'Jane Doe, John Smith' becomes properly linked, deduped authors."""
    import re
    names = []
    for raw in author_names:
        if not raw:
            continue
        names.extend(p.strip() for p in re.split(r",| and | & ", raw) if p.strip())

    with conn.cursor() as cur:
        for name in names:
            author_id = get_or_create_author(conn, name)
            cur.execute(
                """INSERT INTO book_authors (book_id, author_id, role)
                   VALUES (%s, %s, 'author') ON CONFLICT DO NOTHING""",
                (book_id, author_id),
            )
    conn.commit()


def insert_chapters(conn, book_id: str, chapters: list[dict]):
    """chapters: [{index, title, text}, ...] from epub_parser.extract_chapters"""
    with conn.cursor() as cur:
        for ch in chapters:
            cur.execute(
                """INSERT INTO chapters (book_id, chapter_index, title, word_count)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (book_id, chapter_index) DO NOTHING""",
                (book_id, ch["index"], ch["title"], len(ch["text"].split())),
            )
    conn.commit()


def get_chunks_for_chapter(conn, book_id: str, chapter_query: str) -> list[dict]:
    """Chunks whose chapter_title contains chapter_query as a whole token
    (word-boundary regex, so searching '1' won't also match '11' or '21')."""
    import re as _re
    pattern = r"\y" + _re.escape(chapter_query) + r"\y"
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """SELECT chapter_title, chunk_index, text FROM chunks
               WHERE book_id = %s AND chapter_title ~* %s
               ORDER BY chunk_index""",
            (book_id, pattern),
        )
        return cur.fetchall()


def log_query(conn, question: str, model_used: str, answer: str,
              cited: list[dict] = None) -> str:
    """cited: [{chunk_id, score}, ...] — pass whatever query.py's rerank
    step already has, no extra lookups needed."""
    query_id = str(uuid.uuid4())
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO query_history (id, question, model_used, answer) VALUES (%s, %s, %s, %s)",
            (query_id, question, model_used, answer),
        )
        for c in (cited or []):
            cur.execute(
                """INSERT INTO query_citations (query_id, chunk_id, rerank_score)
                   VALUES (%s, %s, %s) ON CONFLICT DO NOTHING""",
                (query_id, c["chunk_id"], c.get("score")),
            )
    conn.commit()
    return query_id


def _normalize_concept_name(name: str) -> str:
    return " ".join(name.strip().lower().split())


def get_or_create_concept(conn, name: str) -> str:
    norm = _normalize_concept_name(name)
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT id FROM concepts WHERE normalized_name = %s", (norm,))
        row = cur.fetchone()
        if row:
            return row["id"]
        concept_id = str(uuid.uuid4())
        cur.execute(
            "INSERT INTO concepts (id, name, normalized_name) VALUES (%s, %s, %s)",
            (concept_id, name.strip(), norm),
        )
    conn.commit()
    return concept_id


def link_book_concept(conn, book_id: str, concept_id: str, description: str, importance: int):
    with conn.cursor() as cur:
        cur.execute(
            """INSERT INTO book_concepts (book_id, concept_id, description, importance)
               VALUES (%s, %s, %s, %s)
               ON CONFLICT (book_id, concept_id)
               DO UPDATE SET description = EXCLUDED.description, importance = EXCLUDED.importance""",
            (book_id, concept_id, description, importance),
        )
    conn.commit()


def save_book_concepts(conn, book_id: str, concepts: list[dict]):
    """concepts: [{concept, description, importance}, ...] from llm.extract_concepts"""
    for c in concepts:
        concept_id = get_or_create_concept(conn, c["concept"])
        link_book_concept(conn, book_id, concept_id, c.get("description", ""), c.get("importance", 3))


def get_book_by_id(conn, book_id: str):
    """Same shape as get_book_report, but looked up by exact id — used by
    the web UI so book detail pages have stable URLs."""
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT * FROM books WHERE id = %s", (book_id,))
        book = cur.fetchone()
        if not book:
            return None
        cur.execute(
            """SELECT c.name, bc.description, bc.importance
               FROM book_concepts bc JOIN concepts c ON c.id = bc.concept_id
               WHERE bc.book_id = %s ORDER BY bc.importance DESC""",
            (book_id,),
        )
        book["concepts"] = cur.fetchall()
        cur.execute(
            "SELECT chapter_index, title, word_count FROM chapters WHERE book_id = %s ORDER BY chapter_index",
            (book_id,),
        )
        book["chapters"] = cur.fetchall()
        return book


def get_book_report(conn, title_query: str):
    """Fetch a book's stored intelligence (metadata, summary, concepts) by
    fuzzy title match — used by book_report.py."""
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            "SELECT * FROM books WHERE title ILIKE %s ORDER BY updated_at DESC LIMIT 1",
            (f"%{title_query}%",),
        )
        book = cur.fetchone()
        if not book:
            return None
        cur.execute(
            """SELECT c.name, bc.description, bc.importance
               FROM book_concepts bc JOIN concepts c ON c.id = bc.concept_id
               WHERE bc.book_id = %s ORDER BY bc.importance DESC""",
            (book["id"],),
        )
        book["concepts"] = cur.fetchall()
        return book


def insert_chunks(conn, book_id: str, chunks: list[dict], embedding_model: str = None) -> list[str]:
    """chunks: [{id, chapter_title, chunk_index, text, word_count}, ...]
    Returns the list of chunk ids (also used as Qdrant point ids).
    embedding_model is recorded per chunk so a future embedding-model
    upgrade can identify exactly which chunks are stale."""
    ids = []
    with conn.cursor() as cur:
        for c in chunks:
            cid = c["id"]
            ids.append(cid)
            cur.execute(
                """INSERT INTO chunks (id, book_id, chapter_title, chunk_index, text,
                                        word_count, embedding_model, embedding_version)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, 1)""",
                (cid, book_id, c.get("chapter_title"), c["chunk_index"],
                 c["text"], c.get("word_count"), embedding_model),
            )
    conn.commit()
    return ids
