"""Remove a book — and all its chunks, chapters, concepts, and Qdrant
vectors — from the library. Mainly for clearing out stuck 'processing' or
'failed' imports (e.g. after a crash mid-import) so the source file can be
re-imported cleanly. Without this, the dedup hash check would silently
treat the file as a duplicate of the broken record and skip it.

Usage:
    python remove_book.py "CSB Ancient Faith"    # fuzzy title match
    python remove_book.py --status processing    # remove ALL stuck imports
    python remove_book.py --status failed         # remove ALL failed imports
    python remove_book.py --status processing --yes   # skip confirmation
"""
import argparse

import psycopg2.extras
from qdrant_client.models import FieldCondition, Filter, MatchValue

from db import CFG, get_conn, get_qdrant


def find_books(conn, title_query: str = None, status: str = None):
    query = "SELECT id, title, author, status FROM books"
    conditions, params = [], []
    if title_query:
        conditions.append("title ILIKE %s")
        params.append(f"%{title_query}%")
    if status:
        conditions.append("status = %s")
        params.append(status)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(query, params)
        return cur.fetchall()


def remove_book(conn, qdrant, book: dict):
    # Safe even if this book never got any vectors uploaded (common for
    # imports that failed before or during the Qdrant upsert step).
    qdrant.delete(
        collection_name=CFG.qdrant_collection,
        points_selector=Filter(
            must=[FieldCondition(key="book_id", match=MatchValue(value=book["id"]))]
        ),
    )
    with conn.cursor() as cur:
        # import_jobs.book_id has no ON DELETE behavior on older schema
        # instances, so clear the reference first rather than let the
        # foreign key block the delete.
        cur.execute("UPDATE import_jobs SET book_id = NULL WHERE book_id = %s", (book["id"],))
        cur.execute("DELETE FROM books WHERE id = %s", (book["id"],))
    conn.commit()
    print(f"Removed: {book['title']!r} [{book['status']}]")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("title", nargs="?", help="Partial title to match")
    parser.add_argument("--status", choices=["pending", "processing", "complete", "failed", "duplicate"])
    parser.add_argument("--yes", action="store_true", help="Skip the confirmation prompt")
    args = parser.parse_args()

    if not args.title and not args.status:
        parser.error("Provide a title, --status, or both")

    conn = get_conn()
    qdrant = get_qdrant()

    books = find_books(conn, args.title, args.status)
    if not books:
        print("No matching books found.")
    else:
        print(f"Found {len(books)} matching book(s):")
        for b in books:
            print(f"  - {b['title']!r} [{b['status']}]")
        if not args.yes:
            confirm = input(f"\nDelete these {len(books)} book(s) and all associated data? [y/N] ")
            if confirm.strip().lower() != "y":
                print("Cancelled.")
                raise SystemExit(0)
        for b in books:
            remove_book(conn, qdrant, b)

    conn.close()
