"""Minimal local web UI for the book intelligence library.

This wraps the existing CLI scripts — it doesn't replace them or change
how the pipeline works. Import still runs from the command line
(`python pipeline.py --once` / `--watch`); this gives you a browsable,
clickable front end for everything else: browsing your library, asking
questions, viewing history, and opening the knowledge/book maps.

Run with:
    cd web
    pip install -r ../requirements.txt   # picks up flask + markdown
    python app.py

Then open http://localhost:5000 — single-user, local-only, no auth.
Not meant to be exposed beyond your own machine.
"""
import contextlib
import io
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import markdown
import psycopg2.extras
from flask import Flask, redirect, render_template, request, send_from_directory, url_for

from db import CFG, get_book_by_id, get_conn
import query as query_module
import writepost as writepost_module

app = Flask(__name__)

LIBRARY_DIR = os.path.join(os.path.dirname(__file__), "..", "library")
SRC_DIR = os.path.join(os.path.dirname(__file__), "..", "src")
FORMATS_DIR = os.path.join(LIBRARY_DIR, "formats")


def list_format_files():
    if not os.path.isdir(FORMATS_DIR):
        return []
    return sorted(f for f in os.listdir(FORMATS_DIR) if f.endswith(".txt"))


PER_PAGE = 10


@app.route("/")
def index():
    page = max(1, request.args.get("page", 1, type=int))
    search = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "").strip()

    conditions, params = [], []
    if search:
        conditions.append("(b.title ILIKE %s OR b.author ILIKE %s)")
        params.extend([f"%{search}%", f"%{search}%"])
    if status_filter:
        conditions.append("b.status = %s")
        params.append(status_filter)
    where_clause = ("WHERE " + " AND ".join(conditions)) if conditions else ""

    conn = get_conn()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(f"SELECT count(*) AS total FROM books b {where_clause}", params)
        total = cur.fetchone()["total"]
        total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
        page = min(page, total_pages)
        offset = (page - 1) * PER_PAGE

        cur.execute(
            f"""SELECT b.id, b.title, b.author, b.status, b.source_format, b.created_at,
                       (SELECT count(*) FROM chunks c WHERE c.book_id = b.id) AS chunk_count,
                       (SELECT count(*) FROM book_concepts bc WHERE bc.book_id = b.id) AS concept_count
                FROM books b {where_clause}
                ORDER BY b.created_at DESC
                LIMIT %s OFFSET %s""",
            params + [PER_PAGE, offset],
        )
        books = cur.fetchall()

        cur.execute(
            """SELECT job_id, file_path, status, stage, error_message, updated_at
               FROM import_jobs ORDER BY updated_at DESC LIMIT 10"""
        )
        jobs = cur.fetchall()
    conn.close()

    return render_template(
        "index.html", books=books, jobs=jobs, total=total, page=page,
        total_pages=total_pages, search=search, status_filter=status_filter,
        range_start=offset + 1 if total else 0, range_end=min(offset + PER_PAGE, total),
    )


@app.route("/book/<book_id>")
def book_detail(book_id):
    conn = get_conn()
    book = get_book_by_id(conn, book_id)
    conn.close()
    if not book:
        return "Book not found", 404
    summary_html = markdown.markdown(book.get("summary") or "*No summary generated.*")
    return render_template("book.html", book=book, summary_html=summary_html)


@app.route("/query", methods=["GET", "POST"])
def query_page():
    answer_html = None
    raw_answer = None
    question = ""
    use_cloud = False
    use_deep = False
    use_research = False
    format_file = ""
    custom_format = ""
    format_files = list_format_files()

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        use_cloud = request.form.get("use_cloud") == "on"
        cloud_provider = request.form.get("cloud_provider", "")
        use_deep = request.form.get("use_deep") == "on"
        use_research = request.form.get("use_research") == "on"
        # A provider string rides inside use_cloud (True = default provider)
        use_cloud_val = (cloud_provider or True) if use_cloud else False
        format_file = request.form.get("format_file", "")
        custom_format = request.form.get("custom_format", "").strip()

        # Custom inline text takes priority over a selected saved file —
        # lets you tweak a format on the fly without editing the file.
        format_instructions = None
        if custom_format:
            format_instructions = custom_format
        elif format_file:
            fpath = os.path.join(FORMATS_DIR, format_file)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    format_instructions = f.read()

        if question:
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    if use_research:
                        query_module.answer_research(
                            question, model=CFG.llm_deep, use_cloud=use_cloud_val,
                            format_instructions=format_instructions,
                        )
                    else:
                        model = CFG.llm_deep if use_deep else CFG.llm_fast
                        query_module.answer(
                            question, model=model, use_cloud=use_cloud_val,
                            format_instructions=format_instructions,
                        )
            except Exception as e:
                buf.write(f"\n\n**Error:** {e}")
            raw_answer = buf.getvalue()
            answer_html = markdown.markdown(raw_answer)

    return render_template(
        "query.html", answer=answer_html, raw_answer=raw_answer, question=question,
        use_cloud=use_cloud, use_deep=use_deep, use_research=use_research,
        format_files=format_files, format_file=format_file, custom_format=custom_format,
        cloud_provider=request.form.get("cloud_provider", CFG.cloud_provider),
    )


@app.route("/query/download", methods=["POST"])
def query_download():
    question = request.form.get("question", "answer")
    answer_text = request.form.get("answer_text", "")
    slug = "".join(c if c.isalnum() or c in " -" else "" for c in question.lower())
    slug = "-".join(slug.split())[:50] or "answer"

    from flask import Response
    content = f"Question: {question}\n{'=' * 60}\n\n{answer_text}\n"
    return Response(
        content,
        mimetype="text/plain",
        headers={"Content-Disposition": f"attachment; filename={slug}.txt"},
    )


@app.route("/write", methods=["GET", "POST"])
def write_page():
    post_html = None
    raw_post = None
    topic = ""
    use_cloud = True
    format_file = ""
    format_files = writepost_module.list_formats()
    suggested_format = None

    if request.method == "POST":
        topic = request.form.get("topic", "").strip()
        use_cloud = request.form.get("use_cloud") == "on"
        cloud_provider = request.form.get("cloud_provider", "")
        format_file = request.form.get("format_file", "")
        use_cloud_val = (cloud_provider or True) if use_cloud else False

        if topic:
            buf = io.StringIO()
            result = None
            try:
                # write_post RETURNS the finished post — the CLI prints that
                # return value explicitly. Capturing stdout alone missed it
                # entirely (cloud runs print almost nothing while executing),
                # which made the web page show status lines instead of the post.
                with contextlib.redirect_stdout(buf):
                    result = writepost_module.write_post(
                        topic,
                        format_name=format_file or None,
                        use_cloud=use_cloud_val,
                        prompt_for_format=False,  # web can't do an interactive terminal prompt
                    )
            except Exception as e:
                buf.write(f"\n\n**Error:** {e}")
            raw_post = result if result else buf.getvalue()
            post_html = markdown.markdown(raw_post)
    else:
        # Show the suggested format on first load, purely as a hint — the
        # actual auto-selection happens fresh when the form is submitted,
        # since the suggestion depends on the topic typed in.
        suggested_format = None

    return render_template(
        "write.html", post=post_html, raw_post=raw_post, topic=topic,
        use_cloud=use_cloud, format_files=format_files, format_file=format_file,
        cloud_provider=request.form.get("cloud_provider", CFG.cloud_provider),
        suggested_format=suggested_format,
    )


@app.route("/write/download", methods=["POST"])
def write_download():
    topic = request.form.get("topic", "post")
    post_text = request.form.get("post_text", "")
    slug = "".join(c if c.isalnum() or c in " -" else "" for c in topic.lower())
    slug = "-".join(slug.split())[:50] or "post"

    from flask import Response
    return Response(
        post_text,
        mimetype="text/plain",
        headers={"Content-Disposition": f"attachment; filename={slug}.txt"},
    )


@app.route("/history")
def history():
    conn = get_conn()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            """SELECT question, model_used, answer, created_at
               FROM query_history ORDER BY created_at DESC LIMIT 50"""
        )
        rows = cur.fetchall()
    conn.close()
    return render_template("history.html", rows=rows)


@app.route("/maps")
def maps():
    kmap_exists = os.path.exists(os.path.join(LIBRARY_DIR, "knowledge_map.html"))
    bmap_exists = os.path.exists(os.path.join(LIBRARY_DIR, "book_map.html"))
    return render_template("maps.html", kmap_exists=kmap_exists, bmap_exists=bmap_exists)


@app.route("/maps/regenerate/<kind>", methods=["POST"])
def regenerate_map(kind):
    script = "knowledge_map.py" if kind == "knowledge" else "book_map.py"
    subprocess.run(
        [sys.executable, script], cwd=SRC_DIR, capture_output=True, text=True, timeout=600
    )
    return redirect(url_for("maps"))


@app.route("/library-files/<path:filename>")
def library_files(filename):
    return send_from_directory(LIBRARY_DIR, filename)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
