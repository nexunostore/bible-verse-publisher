-- Book Intelligence System — Postgres schema
-- Loaded automatically on first container start via docker-entrypoint-initdb.d

CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- for gen_random_uuid()

-- ============================================================================
-- Series (schema only for now — populate later if/when you want multi-volume
-- tracking; safe to leave empty).
-- ============================================================================
CREATE TABLE IF NOT EXISTS series (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    normalized_name TEXT UNIQUE NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- Books
-- ============================================================================
CREATE TABLE IF NOT EXISTS books (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sha256          TEXT UNIQUE NOT NULL,
    title           TEXT,
    author          TEXT,       -- denormalized display copy; see book_authors for structured data
    isbn            TEXT,
    language        TEXT,
    publisher       TEXT,
    published_date  TEXT,
    source_path     TEXT NOT NULL,
    source_format   TEXT NOT NULL DEFAULT 'epub',  -- 'epub' | 'pdf' — pdf unused until that pipeline exists
    ocr_confidence  REAL,       -- unused until PDF/OCR pipeline exists
    cover_path      TEXT,
    summary         TEXT,
    series_id       UUID REFERENCES series(id) ON DELETE SET NULL,    -- unused until series tracking is populated
    volume_number   REAL,                          -- unused until series tracking is populated
    status          TEXT NOT NULL DEFAULT 'pending',  -- pending, processing, complete, failed, duplicate
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_books_sha256 ON books(sha256);
CREATE INDEX IF NOT EXISTS idx_books_status ON books(status);
CREATE INDEX IF NOT EXISTS idx_books_series ON books(series_id);

-- ============================================================================
-- Authors — structured, deduped across the library (books.author above stays
-- as a fast denormalized display string; these tables back "everything by
-- this author" queries and handle multi-author books cleanly).
-- ============================================================================
CREATE TABLE IF NOT EXISTS authors (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    normalized_name TEXT UNIQUE NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS book_authors (
    book_id         UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    author_id       UUID NOT NULL REFERENCES authors(id) ON DELETE CASCADE,
    role            TEXT DEFAULT 'author',  -- author, editor, translator, etc.
    PRIMARY KEY (book_id, author_id, role)
);

CREATE INDEX IF NOT EXISTS idx_book_authors_author ON book_authors(author_id);

-- ============================================================================
-- Chapters — first-class rows, not just a text label on chunks. Needed for
-- per-chapter summaries/stats later; harmless if left at one row per chapter
-- with nothing extra done with it.
-- ============================================================================
CREATE TABLE IF NOT EXISTS chapters (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id         UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    chapter_index   INT NOT NULL,
    title           TEXT,
    word_count      INT,
    summary         TEXT,       -- unused until per-chapter summarization exists
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (book_id, chapter_index)
);

CREATE INDEX IF NOT EXISTS idx_chapters_book ON chapters(book_id);

-- ============================================================================
-- Chunks — the retrieval unit. Includes both vector-search support (via
-- Qdrant, id-linked) and a native Postgres full-text index as a keyword-exact
-- complement to semantic search.
-- ============================================================================
CREATE TABLE IF NOT EXISTS chunks (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id             UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    chapter_title       TEXT,
    chunk_index         INT NOT NULL,
    text                TEXT NOT NULL,
    word_count          INT,
    page_number         INT,        -- unused for EPUB; populated once PDF pipeline exists
    embedding_model     TEXT,       -- e.g. 'nomic-embed-text' — lets you spot stale embeddings after a model change
    embedding_version   INT DEFAULT 1,
    text_search         tsvector GENERATED ALWAYS AS (to_tsvector('english', text)) STORED,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Note: the qdrant point id for a chunk == chunks.id (cast to string).
-- This keeps Postgres (source of truth for text/metadata) and Qdrant
-- (vector index) in lockstep without a separate mapping table.

CREATE INDEX IF NOT EXISTS idx_chunks_book_id ON chunks(book_id);
CREATE INDEX IF NOT EXISTS idx_chunks_text_search ON chunks USING GIN (text_search);

-- ============================================================================
-- Import job tracking
-- ============================================================================
CREATE TABLE IF NOT EXISTS import_jobs (
    job_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_path       TEXT NOT NULL,
    sha256          TEXT,
    status          TEXT NOT NULL DEFAULT 'queued',  -- queued, running, complete, failed, duplicate
    stage           TEXT,  -- hashing, parsing, chunking, embedding, summarizing, extracting_concepts, done
    error_message   TEXT,
    book_id         UUID REFERENCES books(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON import_jobs(status);

-- ============================================================================
-- Concepts / themes — deduped/canonical across the whole library (e.g.
-- "habit formation" mentioned in 5 different books is ONE row here, linked
-- 5 times below).
-- ============================================================================
CREATE TABLE IF NOT EXISTS concepts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    normalized_name TEXT UNIQUE NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- How a specific book treats a specific concept.
CREATE TABLE IF NOT EXISTS book_concepts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id         UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    concept_id      UUID NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
    description     TEXT,      -- how THIS book treats the concept
    importance      SMALLINT,  -- 1-5, how central it is to this book
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (book_id, concept_id)
);

CREATE INDEX IF NOT EXISTS idx_book_concepts_book ON book_concepts(book_id);
CREATE INDEX IF NOT EXISTS idx_book_concepts_concept ON book_concepts(concept_id);

-- Typed relationships between concepts (richer than the "co-occurs in a
-- book" edges the knowledge map derives automatically). Unused until an
-- extraction step populates it — the knowledge map works fine without it.
CREATE TABLE IF NOT EXISTS concept_relations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_a_id    UUID NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
    concept_b_id    UUID NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
    relation_type   TEXT NOT NULL,  -- e.g. agrees_with, contradicts, builds_on, related_to
    source_book_id  UUID REFERENCES books(id) ON DELETE SET NULL,  -- which book's analysis produced this edge
    note            TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_concept_relations_a ON concept_relations(concept_a_id);
CREATE INDEX IF NOT EXISTS idx_concept_relations_b ON concept_relations(concept_b_id);

-- ============================================================================
-- Personal metadata — about YOU and the book, not the book itself. Kept
-- separate from `books` so bibliographic data and personal data don't mix.
-- Unused until you build reading-status tracking; harmless empty.
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_book_meta (
    book_id         UUID PRIMARY KEY REFERENCES books(id) ON DELETE CASCADE,
    reading_status  TEXT DEFAULT 'unread',  -- unread, reading, finished, abandoned
    rating          SMALLINT,               -- 1-5
    date_started    DATE,
    date_finished   DATE,
    notes           TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- Query history — what you've asked the library and what got cited back.
-- Unused until query.py starts logging; harmless empty, and the logging
-- hook is already wired in below.
-- ============================================================================
CREATE TABLE IF NOT EXISTS query_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question        TEXT NOT NULL,
    model_used      TEXT,
    answer          TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS query_citations (
    query_id        UUID NOT NULL REFERENCES query_history(id) ON DELETE CASCADE,
    chunk_id        UUID NOT NULL REFERENCES chunks(id) ON DELETE CASCADE,
    rerank_score    REAL,
    PRIMARY KEY (query_id, chunk_id)
);
