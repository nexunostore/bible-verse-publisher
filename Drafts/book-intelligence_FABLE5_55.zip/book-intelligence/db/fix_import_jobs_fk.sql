-- Fixes the import_jobs -> books foreign key so deleting a book (e.g. via
-- remove_book.py or manual SQL) doesn't get blocked by its own job history.
-- Safe to run once against an existing database.
--
--   docker exec -i book_intel_postgres psql -U bookintel -d bookintel < db/fix_import_jobs_fk.sql

ALTER TABLE import_jobs DROP CONSTRAINT IF EXISTS import_jobs_book_id_fkey;
ALTER TABLE import_jobs ADD CONSTRAINT import_jobs_book_id_fkey
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE SET NULL;

ALTER TABLE concept_relations DROP CONSTRAINT IF EXISTS concept_relations_source_book_id_fkey;
ALTER TABLE concept_relations ADD CONSTRAINT concept_relations_source_book_id_fkey
    FOREIGN KEY (source_book_id) REFERENCES books(id) ON DELETE SET NULL;

ALTER TABLE books DROP CONSTRAINT IF EXISTS books_series_id_fkey;
ALTER TABLE books ADD CONSTRAINT books_series_id_fkey
    FOREIGN KEY (series_id) REFERENCES series(id) ON DELETE SET NULL;
